---
name: GHL Workflow
description: >
  GoHighLevel command center. Trigger when the user mentions GHL, GoHighLevel,
  CRM contacts, workflows, tags, custom fields, pipelines, opportunities,
  outreach, bulk operations, lead management, or anything related to managing
  contacts and automations in GoHighLevel. Also trigger when the user wants to
  add/find/update/delete contacts, manage tags, run workflows, update custom
  fields, create pipeline opportunities, send emails or SMS through GHL, or
  perform bulk CRM operations. Err toward activating — if the user is talking
  about CRM or lead management, this skill likely applies.
version: 1.1.0
author: OpenClaw Workshop
---

# GHL Workflow — GoHighLevel Command Center

## Purpose

Provide a complete, conversational interface to GoHighLevel's CRM via the v2
Private Integration API. Every command runs through `scripts/ghl_workflow.py`
(stdlib-only Python) so there are zero pip dependencies.

## Onboarding (First Run)

On first activation, check whether credentials exist. The script stores them in
`~/.openclaw/workspace/.env.personal` because that file persists across sessions
and keeps secrets out of chat history.

### Step 1 — Detect credentials

```bash
python3 scripts/ghl_workflow.py test-connection
```

If the output contains `"status": "error"`, credentials are missing. Proceed to
Step 2. If `"status": "connected"`, skip to **Show Command Menu**.

### Step 2 — Collect credentials

Ask the user:

> Welcome! Let me set up your GoHighLevel connection.
>
> I need two things from your GHL Private Integration:
> 1. **Private Integration Token** (starts with `pit-`)
> 2. **Location ID** (alphanumeric string from your GHL sub-account)
>
> You can find both in GHL → Settings → Integrations → Private Integrations.

### Step 3 — Save and verify

```bash
python3 scripts/ghl_workflow.py save-credentials --token "USER_TOKEN" --location-id "USER_LOCATION_ID"
python3 scripts/ghl_workflow.py test-connection
```

If the test fails, show the error and ask the user to double-check. Do not
proceed until the connection succeeds.

### Step 4 — Show Command Menu

Once connected, display the full command menu so the user sees everything
available at a glance. This is critical for first impressions — show all
capabilities immediately:

```
🚀 GHL Workflow — Your GoHighLevel Command Center

Connected to location: {location_id} ✓

Here's everything I can do:

📇 CONTACTS
  /ghl workflow — Full GHL integration (add contact + tags + workflows)
  /find-contact — Search for an existing contact
  /get-contact — Get full contact details by ID
  /update-contact — Update contact details
  /delete-contact — Remove a contact
  /list-contacts — List recent contacts

🏷️ TAGS & TRIGGERS
  /add-tag — Add tags to a contact
  /remove-tag — Remove tags from a contact
  /list-tags — Show all tags on a contact
  /trigger-by-tag — Trigger a GHL workflow by adding a specific tag

⚡ WORKFLOWS
  /add-to-workflow — Add a contact to a workflow directly
  /list-workflows — Show all available workflows
  /remove-from-workflow — Remove contact from workflow

📋 CUSTOM FIELDS
  /update-fields — Update custom fields on a contact
  /list-fields — Show all available custom fields
  /get-fields — Show a contact's current custom field values

📊 PIPELINES
  /list-pipelines — Show all pipelines and stages
  /add-opportunity — Create an opportunity for a contact
  /move-stage — Move an opportunity to a different stage

📧 OUTREACH
  /send-email — Send an email to a contact (via workflow)
  /send-sms — Send an SMS to a contact (via workflow)

🔄 BULK OPERATIONS
  /bulk-add — Add multiple contacts at once
  /bulk-tag — Tag multiple contacts
  /bulk-workflow — Add multiple contacts to a workflow

Just tell me what you want to do, or use any command above!
```

Then ask: **"What would you like to do first?"**

---

## Level 1 — Core Flow & The Tag-Trigger Pattern

The most powerful pattern in GHL is the **Tag-Trigger Workflow**. Since the
Private Integration API cannot directly send emails or SMS, we use tags as the
bridge to GHL's automation engine.

### WHY this is powerful:
1. **Bridge to Automation**: Adding a tag via API triggers any workflow in GHL
   that has a "Contact Tag" trigger for that tag.
2. **No Direct API Needed**: You can trigger complex email sequences, SMS
   follow-ups, or pipeline moves without needing direct API access to those
   features.
3. **User-Friendly**: The user sets up the automation in GHL's visual builder,
   and the skill just "pulls the lever" by adding the tag.

### How to set it up:
1. In GHL, create a workflow with the trigger **"Contact Tag"**.
2. Select **"Tag Added"** and specify the tag (e.g., `trigger-welcome-email`).
3. Use the skill to add that tag to a contact:
   ```bash
   python3 scripts/ghl_workflow.py trigger-by-tag --id "CONTACT_ID" --tag "trigger-welcome-email"
   ```

---

## Level 2 — Individual Commands

### `/ghl workflow` — Full GHL Integration

Complete workflow for adding a contact to GHL with tags and workflow enrollment.

**Usage:**
```
User: /ghl workflow
Agent: Email address?
User: john@example.com
Agent: First name?
User: John
Agent: Last name?
User: Doe
Agent: Phone?
User: +1234567890
Agent: Company?
User: Acme Corp
Agent: Tags to add? (comma-separated, or 'none')
User: new-lead,vip
Agent: Add to workflow? (provide workflow ID or 'none')
User: workflow-uuid-here
```

**What it does:**
1. Collects contact details (email required, rest optional)
2. Creates contact in GHL via API
3. Adds specified tags
4. Enrolls in specified workflow (if provided)
5. Returns contact ID + confirmation

**Implementation:**
```python
# 1. Create contact
contact = add_contact(data)
contact_id = contact['id']

# 2. Add tags
if tags:
    add_tag(contact_id, tags)

# 3. Add to workflow
if workflow_id:
    add_to_workflow(contact_id, workflow_id)

# 4. Confirm
print(f"✅ Contact created in GHL!")
print(f"Contact ID: {contact_id}")
print(f"Tags: {tags}")
print(f"Workflow: {workflow_id}")
```

**Rules:**
- Email is REQUIRED
- Tags and workflow are OPTIONAL
- Always confirm before executing
- Show contact ID after creation

---

### Contacts
**Add a contact:**
```bash
python3 scripts/ghl_workflow.py add-contact --data '{"firstName":"Jane","lastName":"Smith","email":"jane@acme.com","phone":"+15551234567","companyName":"Acme Inc","tags":["new-lead"]}'
```

**Find a contact:**
```bash
python3 scripts/ghl_workflow.py find-contact --query "jane@acme.com"
```

### Tags & Triggers
**Trigger a workflow by tag:**
```bash
python3 scripts/ghl_workflow.py trigger-by-tag --id "CONTACT_ID" --tag "trigger-tag"
```
Explain to the user that this tag will fire any associated GHL workflows.

**Add tags:**
```bash
python3 scripts/ghl_workflow.py add-tag --id "CONTACT_ID" --tags "vip,hot-lead"
```

### Workflows
**List all workflows:**
```bash
python3 scripts/ghl_workflow.py list-workflows
```

**Add contact to workflow directly:**
```bash
python3 scripts/ghl_workflow.py add-to-workflow --id "CONTACT_ID" --workflow-id "WORKFLOW_UUID"
```

### Custom Fields
**Update custom fields:**
```bash
python3 scripts/ghl_workflow.py update-fields --id "CONTACT_ID" --fields '{"contact.project_budget":"50000"}'
```

### Pipelines & Opportunities
**Create an opportunity:**
```bash
python3 scripts/ghl_workflow.py add-opportunity --data '{"contactId":"ID","pipelineId":"PID","name":"Jane Smith - Deal","pipelineStageId":"STAGE_ID","monetaryValue":5000}'
```

### Outreach
**Send email/SMS:**
```bash
python3 scripts/ghl_workflow.py send-email --id "CONTACT_ID" --subject "Welcome" --body "Hello!"
```
The skill will suggest using `/trigger-by-tag` to fire an email workflow in GHL.

---

## Level 3 — Edge Cases and Error Handling

### Workflow selection
When the user says "add to workflow" without specifying which one, list the
available workflows and ask them to pick.

### API errors
All errors are returned as JSON with an `error` key. Present them conversationally:
> "GHL returned an error: {message}. This usually means {explanation}."

---

## File Reference

| File | Purpose |
|------|---------|
| `scripts/ghl_workflow.py` | All GHL API operations — stdlib-only Python |
| `references/ghl-workflow-reference.md` | Full API endpoint reference |
