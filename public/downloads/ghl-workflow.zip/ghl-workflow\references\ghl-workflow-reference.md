# GoHighLevel API Reference for GHL Workflow Skill

This document outlines the GoHighLevel (GHL) API endpoints utilized by the GHL Workflow skill. The integration relies on the GHL v2.0 API using Private Integration Tokens.

## Authentication and Base Configuration

All requests to the GHL API require a Private Integration Token and a specific API version header. The base URL for all endpoints is `https://services.leadconnectorhq.com`.

The required headers for every request are as follows:
- `Authorization: Bearer {GHL_PRIVATE_TOKEN}`
- `Version: 2021-07-28`
- `Content-Type: application/json`
- `Accept: application/json`

## The Tag-Trigger Workflow Pattern

A key feature of this skill is the ability to trigger GHL workflows via tags. This is the recommended way to trigger emails, SMS, and other automations through the Private Integration API.

1. **Setup in GHL**: Create a workflow with the "Contact Tag" trigger (Tag Added).
2. **Execution via Skill**: Use the `/trigger-by-tag` command to add the specified tag to a contact.
3. **Result**: GHL detects the tag addition and automatically executes the workflow actions.

## Contacts API

### Create Contact
**Endpoint:** `POST /contacts/`
**Purpose:** Creates a new contact record.

### Search Contacts
**Endpoint:** `GET /contacts/?locationId={ID}&query={QUERY}`
**Purpose:** Finds contacts by name, email, or phone.

### Update Contact
**Endpoint:** `PUT /contacts/{contactId}`
**Purpose:** Updates standard contact fields.

## Tags & Triggers API

### Add Tags
**Endpoint:** `POST /contacts/{contactId}/tags`
**Request Body:** `{"tags": ["tag1", "tag2"]}`
**Purpose:** Appends tags to a contact. This is the underlying mechanism for `/trigger-by-tag`.

### Remove Tags
**Endpoint:** `DELETE /contacts/{contactId}/tags`
**Purpose:** Removes specific tags from a contact.

## Workflows API

### List Workflows
**Endpoint:** `GET /workflows/?locationId={LOCATION_ID}`
**Purpose:** Retrieves all workflows in the location.

### Add to Workflow
**Endpoint:** `POST /contacts/{contactId}/workflow/{workflowId}`
**Purpose:** Directly adds a contact to a workflow.

## Custom Fields API

### List Custom Fields
**Endpoint:** `GET /locations/{LOCATION_ID}/customFields`
**Purpose:** Retrieves custom field definitions.

### Update Custom Fields
**Endpoint:** `PUT /contacts/{contactId}`
**Request Body:** `{"customFields": [{"id": "field_id", "field_value": "value"}]}`
**Purpose:** Updates custom field values on a contact.

## Pipelines & Opportunities API

### List Pipelines
**Endpoint:** `GET /opportunities/pipelines?locationId={LOCATION_ID}`
**Purpose:** Retrieves pipelines and stages.

### Create Opportunity
**Endpoint:** `POST /opportunities/`
**Purpose:** Adds a contact to a pipeline stage.

## Error Handling

- **400 Bad Request**: Missing required fields or invalid data.
- **401 Unauthorized**: Invalid or expired token.
- **429 Too Many Requests**: Rate limit exceeded (handled with backoff).
- **500 Internal Server Error**: GHL server issue (handled with retries).
