#!/usr/bin/env python3
"""
ghl_workflow.py — GoHighLevel API Command Center
Uses only Python standard library (urllib, json). No pip installs required.

Reads credentials from environment variables or ~/.openclaw/workspace/.env.personal:
    GHL_PRIVATE_TOKEN  — Private Integration Token (pit-...)
    GHL_LOCATION_ID    — Location ID

Commands:
    python3 ghl_workflow.py test-connection
    python3 ghl_workflow.py add-contact --data '{"firstName":"John",...}'
    python3 ghl_workflow.py find-contact --query "john@example.com"
    python3 ghl_workflow.py get-contact --id "abc123"
    python3 ghl_workflow.py update-contact --id "abc123" --data '{"firstName":"Jane"}'
    python3 ghl_workflow.py delete-contact --id "abc123"
    python3 ghl_workflow.py add-tag --id "abc123" --tags "vip,hot-lead"
    python3 ghl_workflow.py remove-tag --id "abc123" --tags "old-tag"
    python3 ghl_workflow.py list-tags --id "abc123"
    python3 ghl_workflow.py trigger-by-tag --id "abc123" --tag "trigger-tag"
    python3 ghl_workflow.py list-workflows
    python3 ghl_workflow.py add-to-workflow --id "abc123" --workflow-id "uuid"
    python3 ghl_workflow.py remove-from-workflow --id "abc123" --workflow-id "uuid"
    python3 ghl_workflow.py list-fields
    python3 ghl_workflow.py get-fields --id "abc123"
    python3 ghl_workflow.py update-fields --id "abc123" --fields '{"field_key":"value"}'
    python3 ghl_workflow.py list-pipelines
    python3 ghl_workflow.py add-opportunity --data '{"contactId":"...","pipelineId":"...","name":"Deal"}'
    python3 ghl_workflow.py move-stage --id "oppId" --stage-id "stageId"
    python3 ghl_workflow.py send-email --id "abc123" --subject "Hi" --body "Hello there"
    python3 ghl_workflow.py send-sms --id "abc123" --message "Hello"
    python3 ghl_workflow.py bulk-add --file contacts.json
    python3 ghl_workflow.py bulk-tag --ids "id1,id2,id3" --tags "tag1,tag2"
    python3 ghl_workflow.py bulk-workflow --ids "id1,id2" --workflow-id "uuid"
    python3 ghl_workflow.py save-credentials --token "pit-..." --location-id "abc"
    python3 ghl_workflow.py list-contacts --limit 20
"""

import urllib.request
import urllib.error
import urllib.parse
import json
import sys
import os
import ssl
import time
import argparse

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

BASE_URL = "https://services.leadconnectorhq.com"
API_VERSION = "2021-07-28"
SOURCE_NAME = "GHL Workflow Skill"
MAX_RETRIES = 3
RETRY_DELAY = 2
REQUEST_TIMEOUT = 25

# SSL context — some sandbox environments need relaxed SSL
SSL_CTX = ssl.create_default_context()
SSL_CTX.check_hostname = False
SSL_CTX.verify_mode = ssl.CERT_NONE

ENV_FILE = os.path.expanduser("~/.openclaw/workspace/.env.personal")


# ---------------------------------------------------------------------------
# Credential helpers
# ---------------------------------------------------------------------------

def _load_env_file():
    """Parse .env.personal file into a dict."""
    env = {}
    if os.path.isfile(ENV_FILE):
        with open(ENV_FILE) as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                if "=" in line:
                    key, _, val = line.partition("=")
                    env[key.strip()] = val.strip().strip('"').strip("'")
    return env


def _get_token():
    """Get GHL Private Integration Token from env or config file."""
    token = os.environ.get("GHL_PRIVATE_TOKEN", "")
    if not token:
        env = _load_env_file()
        token = env.get("GHL_PRIVATE_TOKEN", "")
    if not token:
        raise RuntimeError(
            "GHL_PRIVATE_TOKEN not set. Run: python3 ghl_workflow.py save-credentials "
            "--token 'pit-...' --location-id 'your-id'"
        )
    return token


def _get_location_id():
    """Get GHL Location ID from env or config file."""
    loc_id = os.environ.get("GHL_LOCATION_ID", "")
    if not loc_id:
        env = _load_env_file()
        loc_id = env.get("GHL_LOCATION_ID", "")
    if not loc_id:
        raise RuntimeError(
            "GHL_LOCATION_ID not set. Run: python3 ghl_workflow.py save-credentials "
            "--token 'pit-...' --location-id 'your-id'"
        )
    return loc_id


def save_credentials(token, location_id):
    """Save GHL credentials to ~/.openclaw/workspace/.env.personal."""
    os.makedirs(os.path.dirname(ENV_FILE), exist_ok=True)

    # Read existing env file, update or add our keys
    existing = {}
    if os.path.isfile(ENV_FILE):
        with open(ENV_FILE) as f:
            for line in f:
                line_s = line.strip()
                if not line_s or line_s.startswith("#"):
                    continue
                if "=" in line_s:
                    k, _, v = line_s.partition("=")
                    existing[k.strip()] = v.strip()

    existing["GHL_PRIVATE_TOKEN"] = token
    existing["GHL_LOCATION_ID"] = location_id

    with open(ENV_FILE, "w") as f:
        f.write("# GHL Workflow credentials\n")
        for k, v in existing.items():
            f.write(f"{k}={v}\n")

    # Also set in current process
    os.environ["GHL_PRIVATE_TOKEN"] = token
    os.environ["GHL_LOCATION_ID"] = location_id

    return {"status": "saved", "env_file": ENV_FILE}


# ---------------------------------------------------------------------------
# HTTP helper
# ---------------------------------------------------------------------------

def _request(method, path, body=None, retries=MAX_RETRIES):
    """
    Make an authenticated request to the GHL API.
    Handles retries for rate limits (429) and server errors (5xx).
    Returns parsed JSON response.
    """
    token = _get_token()
    url = f"{BASE_URL}{path}"

    headers = {
        "Authorization": f"Bearer {token}",
        "Version": API_VERSION,
        "Content-Type": "application/json",
        "Accept": "application/json",
        "User-Agent": "GHLWorkflowSkill/1.0",
    }

    data = json.dumps(body).encode("utf-8") if body else None

    for attempt in range(retries):
        try:
            req = urllib.request.Request(url, data=data, headers=headers, method=method)
            with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT, context=SSL_CTX) as resp:
                resp_body = resp.read().decode("utf-8")
                return json.loads(resp_body) if resp_body else {}
        except urllib.error.HTTPError as exc:
            error_body = ""
            try:
                error_body = exc.read().decode("utf-8")
            except Exception:
                pass
            if exc.code == 429:
                wait = RETRY_DELAY * (attempt + 1) * 2
                time.sleep(wait)
                continue
            elif exc.code >= 500 and attempt < retries - 1:
                time.sleep(RETRY_DELAY * (attempt + 1))
                continue
            else:
                # Try to parse error body for a cleaner message
                try:
                    err_json = json.loads(error_body)
                    msg = err_json.get("message", error_body)
                except Exception:
                    msg = error_body
                raise RuntimeError(
                    f"GHL API error {exc.code} {method} {path}: {msg}"
                ) from exc
        except (urllib.error.URLError, OSError) as exc:
            if attempt < retries - 1:
                time.sleep(RETRY_DELAY * (attempt + 1))
            else:
                raise RuntimeError(f"Network error {method} {path}: {exc}") from exc


# ---------------------------------------------------------------------------
# CONTACTS
# ---------------------------------------------------------------------------

def add_contact(contact_data):
    """Create a new contact in GHL. Returns the created contact with ID."""
    location_id = _get_location_id()
    payload = {"locationId": location_id, "source": SOURCE_NAME}

    allowed = [
        "firstName", "lastName", "name", "phone", "email",
        "address1", "city", "state", "postalCode", "website",
        "tags", "companyName", "country", "dateOfBirth", "gender",
    ]
    for key in allowed:
        if key in contact_data and contact_data[key]:
            payload[key] = contact_data[key]

    # Ensure tags is a list
    if "tags" in payload and isinstance(payload["tags"], str):
        payload["tags"] = [t.strip() for t in payload["tags"].split(",")]

    result = _request("POST", "/contacts/", body=payload)
    return result.get("contact", result)


def find_contact(query):
    """
    Search for a contact by name, email, or phone.
    Uses the list endpoint with query param for name search,
    and the duplicate endpoint for exact email/phone lookup.
    """
    location_id = _get_location_id()

    # Try duplicate search first (exact match on email or phone)
    if "@" in query:
        dup = _request("GET", f"/contacts/search/duplicate?locationId={location_id}&email={urllib.parse.quote(query)}")
        if dup.get("contact"):
            return [dup["contact"]]
    elif query.startswith("+") or query.replace("-", "").replace(" ", "").isdigit():
        dup = _request("GET", f"/contacts/search/duplicate?locationId={location_id}&number={urllib.parse.quote(query)}")
        if dup.get("contact"):
            return [dup["contact"]]

    # Fall back to query search (name, partial match)
    result = _request("GET", f"/contacts/?locationId={location_id}&query={urllib.parse.quote(query)}&limit=20")
    return result.get("contacts", [])


def get_contact(contact_id):
    """Get a single contact by ID."""
    result = _request("GET", f"/contacts/{contact_id}")
    return result.get("contact", result)


def update_contact(contact_id, update_data):
    """Update standard fields on a contact (firstName, lastName, email, phone, etc.)."""
    result = _request("PUT", f"/contacts/{contact_id}", body=update_data)
    return result.get("contact", result)


def delete_contact(contact_id):
    """Delete a contact by ID."""
    return _request("DELETE", f"/contacts/{contact_id}")


def list_contacts(limit=20):
    """List contacts in the location."""
    location_id = _get_location_id()
    result = _request("GET", f"/contacts/?locationId={location_id}&limit={limit}")
    return result.get("contacts", [])


# ---------------------------------------------------------------------------
# TAGS
# ---------------------------------------------------------------------------

def add_tag(contact_id, tags):
    """Add one or more tags to a contact. Tags is a list of strings."""
    if isinstance(tags, str):
        tags = [t.strip() for t in tags.split(",")]
    result = _request("POST", f"/contacts/{contact_id}/tags", body={"tags": tags})
    return result


def remove_tag(contact_id, tags):
    """Remove one or more tags from a contact."""
    if isinstance(tags, str):
        tags = [t.strip() for t in tags.split(",")]
    result = _request("DELETE", f"/contacts/{contact_id}/tags", body={"tags": tags})
    return result


def list_tags(contact_id):
    """List all tags on a contact."""
    contact = get_contact(contact_id)
    return {"contactId": contact_id, "tags": contact.get("tags", [])}


def trigger_by_tag(contact_id, tag):
    """
    Add a tag to a contact to trigger an associated workflow in GHL.
    This is a powerful pattern where the tag acts as the bridge to GHL automation.
    """
    result = add_tag(contact_id, [tag])
    return {
        "status": "success",
        "message": f"Tag '{tag}' added to contact {contact_id}.",
        "note": "In GHL, any workflow with a 'Contact Tag' trigger for this tag will now fire automatically.",
        "details": result
    }


# ---------------------------------------------------------------------------
# WORKFLOWS
# ---------------------------------------------------------------------------

def list_workflows():
    """List all workflows in the location."""
    location_id = _get_location_id()
    result = _request("GET", f"/workflows/?locationId={location_id}")
    return result.get("workflows", [])


def add_to_workflow(contact_id, workflow_id):
    """Add a contact to a workflow."""
    result = _request("POST", f"/contacts/{contact_id}/workflow/{workflow_id}")
    return result


def remove_from_workflow(contact_id, workflow_id):
    """Remove a contact from a workflow."""
    result = _request("DELETE", f"/contacts/{contact_id}/workflow/{workflow_id}")
    return result


# ---------------------------------------------------------------------------
# CUSTOM FIELDS
# ---------------------------------------------------------------------------

def list_fields():
    """List all custom fields defined in the location."""
    location_id = _get_location_id()
    result = _request("GET", f"/locations/{location_id}/customFields")
    return result.get("customFields", [])


def get_fields(contact_id):
    """Get a contact's current custom field values."""
    contact = get_contact(contact_id)
    return {
        "contactId": contact_id,
        "customFields": contact.get("customFields", []),
    }


def update_fields(contact_id, fields_data):
    """
    Update custom fields on a contact.
    fields_data can be:
      - dict mapping field_key or field_id to value
      - list of {id, field_value} dicts (passed directly)
    """
    if isinstance(fields_data, dict):
        # Convert key-value dict to GHL format
        # First, get available fields to resolve keys to IDs
        available = list_fields()
        field_map = {}
        for f in available:
            field_map[f.get("fieldKey", "")] = f["id"]
            field_map[f.get("name", "")] = f["id"]
            field_map[f["id"]] = f["id"]

        cf_list = []
        for key, value in fields_data.items():
            field_id = field_map.get(key, key)
            cf_list.append({"id": field_id, "field_value": value})
    elif isinstance(fields_data, list):
        cf_list = fields_data
    else:
        raise ValueError("fields_data must be a dict or list")

    result = _request("PUT", f"/contacts/{contact_id}", body={"customFields": cf_list})
    return result.get("contact", result)


# ---------------------------------------------------------------------------
# PIPELINES & OPPORTUNITIES
# ---------------------------------------------------------------------------

def list_pipelines():
    """List all pipelines and their stages."""
    location_id = _get_location_id()
    result = _request("GET", f"/opportunities/pipelines?locationId={location_id}")
    return result.get("pipelines", [])


def add_opportunity(opp_data):
    """
    Create an opportunity for a contact in a pipeline.
    Required: contactId, pipelineId, name
    Optional: pipelineStageId, status, monetaryValue
    """
    location_id = _get_location_id()
    payload = {
        "locationId": location_id,
        "status": opp_data.get("status", "open"),
    }
    for key in ["contactId", "pipelineId", "pipelineStageId", "name", "monetaryValue"]:
        if key in opp_data:
            payload[key] = opp_data[key]

    result = _request("POST", "/opportunities/", body=payload)
    return result.get("opportunity", result)


def move_stage(opportunity_id, stage_id):
    """Move an opportunity to a different pipeline stage."""
    result = _request("PUT", f"/opportunities/{opportunity_id}", body={
        "pipelineStageId": stage_id,
    })
    return result.get("opportunity", result)


# ---------------------------------------------------------------------------
# OUTREACH (Email & SMS via contact update / notes)
# ---------------------------------------------------------------------------

def send_email(contact_id, subject, body, email_from=None):
    """
    Send an email to a contact.
    Note: GHL v2 Private Integration uses the conversations/messages endpoint
    or the contacts action trigger. We use the create-email action approach.
    """
    return {
        "status": "info",
        "message": (
            "Direct email sending requires the Conversations API scope or an email workflow. "
            "Recommended approach: use /trigger-by-tag to add a tag that triggers an email workflow, "
            "or use /add-to-workflow to trigger an email workflow directly."
        ),
        "contactId": contact_id,
        "subject": subject,
        "suggestion": "Create a workflow in GHL with an email action, then use trigger-by-tag.",
    }


def send_sms(contact_id, message):
    """
    Send an SMS to a contact.
    Note: Similar to email, direct SMS requires Conversations API scope.
    """
    return {
        "status": "info",
        "message": (
            "Direct SMS sending requires the Conversations API scope or an SMS workflow. "
            "Recommended approach: use /trigger-by-tag to add a tag that triggers an SMS workflow, "
            "or use /add-to-workflow to trigger an SMS workflow directly."
        ),
        "contactId": contact_id,
        "sms_body": message,
        "suggestion": "Create a workflow in GHL with an SMS action, then use trigger-by-tag.",
    }


# ---------------------------------------------------------------------------
# BULK OPERATIONS
# ---------------------------------------------------------------------------

def bulk_add(contacts_list):
    """
    Add multiple contacts at once.
    contacts_list: list of contact dicts (same format as add-contact).
    Returns summary with created/failed counts.
    """
    created = 0
    failed = 0
    results = []

    for i, contact_data in enumerate(contacts_list):
        try:
            contact = add_contact(contact_data)
            cid = contact.get("id", "")
            created += 1
            results.append({
                "index": i,
                "status": "created",
                "contactId": cid,
                "name": contact_data.get("name", contact_data.get("firstName", "?")),
            })
            time.sleep(0.3)  # Rate limit protection
        except Exception as exc:
            failed += 1
            results.append({
                "index": i,
                "status": "failed",
                "error": str(exc),
                "name": contact_data.get("name", contact_data.get("firstName", "?")),
            })

    return {"created": created, "failed": failed, "total": len(contacts_list), "results": results}


def bulk_tag(contact_ids, tags):
    """Add tags to multiple contacts."""
    if isinstance(contact_ids, str):
        contact_ids = [cid.strip() for cid in contact_ids.split(",")]
    if isinstance(tags, str):
        tags = [t.strip() for t in tags.split(",")]

    results = []
    for cid in contact_ids:
        try:
            result = add_tag(cid, tags)
            results.append({"contactId": cid, "status": "tagged", "tags": result.get("tagsAdded", tags)})
            time.sleep(0.2)
        except Exception as exc:
            results.append({"contactId": cid, "status": "failed", "error": str(exc)})

    success = sum(1 for r in results if r["status"] == "tagged")
    return {"tagged": success, "failed": len(results) - success, "total": len(contact_ids), "results": results}


def bulk_workflow(contact_ids, workflow_id):
    """Add multiple contacts to a workflow."""
    if isinstance(contact_ids, str):
        contact_ids = [cid.strip() for cid in contact_ids.split(",")]

    results = []
    for cid in contact_ids:
        try:
            add_to_workflow(cid, workflow_id)
            results.append({"contactId": cid, "status": "added"})
            time.sleep(0.2)
        except Exception as exc:
            results.append({"contactId": cid, "status": "failed", "error": str(exc)})

    success = sum(1 for r in results if r["status"] == "added")
    return {"added": success, "failed": len(results) - success, "total": len(contact_ids), "results": results}


# ---------------------------------------------------------------------------
# Connection test
# ---------------------------------------------------------------------------

def test_connection():
    """Test the GHL API connection by listing contacts."""
    try:
        contacts = list_contacts(limit=1)
        return {
            "status": "connected",
            "message": "GHL API connection successful.",
            "location_id": _get_location_id(),
            "contacts_found": len(contacts),
        }
    except Exception as exc:
        return {"status": "error", "message": str(exc)}


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def _output(data):
    """Print JSON output."""
    print(json.dumps(data, indent=2, default=str))


def main():
    parser = argparse.ArgumentParser(
        description="GHL Workflow — GoHighLevel API Command Center",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Commands:
  test-connection      Test GHL API connection
  save-credentials     Save GHL token and location ID
  list-contacts        List contacts
  add-contact          Create a new contact
  find-contact         Search for a contact
  get-contact          Get contact by ID
  update-contact       Update contact details
  delete-contact       Delete a contact
  add-tag              Add tags to a contact
  remove-tag           Remove tags from a contact
  list-tags            Show tags on a contact
  trigger-by-tag       Trigger a GHL workflow by adding a tag
  list-workflows       List all workflows
  add-to-workflow      Add contact to a workflow
  remove-from-workflow Remove contact from workflow
  list-fields          List custom fields
  get-fields           Get contact's custom field values
  update-fields        Update custom fields on a contact
  list-pipelines       List pipelines and stages
  add-opportunity      Create a pipeline opportunity
  move-stage           Move opportunity to different stage
  send-email           Send email (via workflow)
  send-sms             Send SMS (via workflow)
  bulk-add             Add multiple contacts from JSON file
  bulk-tag             Tag multiple contacts
  bulk-workflow        Add multiple contacts to a workflow
        """,
    )
    sub = parser.add_subparsers(dest="command")

    # test-connection
    sub.add_parser("test-connection", help="Test GHL API connection")

    # save-credentials
    sc = sub.add_parser("save-credentials", help="Save GHL credentials")
    sc.add_argument("--token", required=True, help="GHL Private Integration Token")
    sc.add_argument("--location-id", required=True, help="GHL Location ID")

    # list-contacts
    lc = sub.add_parser("list-contacts", help="List contacts")
    lc.add_argument("--limit", type=int, default=20, help="Max contacts (default 20)")

    # add-contact
    ac = sub.add_parser("add-contact", help="Create a new contact")
    ac.add_argument("--data", required=True, help="JSON string with contact data")

    # find-contact
    fc = sub.add_parser("find-contact", help="Search for a contact")
    fc.add_argument("--query", required=True, help="Name, email, or phone to search")

    # get-contact
    gc = sub.add_parser("get-contact", help="Get contact by ID")
    gc.add_argument("--id", required=True, help="Contact ID")

    # update-contact
    uc = sub.add_parser("update-contact", help="Update contact details")
    uc.add_argument("--id", required=True, help="Contact ID")
    uc.add_argument("--data", required=True, help="JSON string with fields to update")

    # delete-contact
    dc = sub.add_parser("delete-contact", help="Delete a contact")
    dc.add_argument("--id", required=True, help="Contact ID")

    # add-tag
    at = sub.add_parser("add-tag", help="Add tags to a contact")
    at.add_argument("--id", required=True, help="Contact ID")
    at.add_argument("--tags", required=True, help="Comma-separated tags")

    # remove-tag
    rt = sub.add_parser("remove-tag", help="Remove tags from a contact")
    rt.add_argument("--id", required=True, help="Contact ID")
    rt.add_argument("--tags", required=True, help="Comma-separated tags")

    # list-tags
    lt = sub.add_parser("list-tags", help="Show tags on a contact")
    lt.add_argument("--id", required=True, help="Contact ID")

    # trigger-by-tag
    tt = sub.add_parser("trigger-by-tag", help="Trigger a GHL workflow by adding a tag")
    tt.add_argument("--id", required=True, help="Contact ID")
    tt.add_argument("--tag", required=True, help="Tag to add (must match GHL workflow trigger)")

    # list-workflows
    sub.add_parser("list-workflows", help="List all workflows")

    # add-to-workflow
    aw = sub.add_parser("add-to-workflow", help="Add contact to a workflow")
    aw.add_argument("--id", required=True, help="Contact ID")
    aw.add_argument("--workflow-id", required=True, help="Workflow ID")

    # remove-from-workflow
    rw = sub.add_parser("remove-from-workflow", help="Remove contact from workflow")
    rw.add_argument("--id", required=True, help="Contact ID")
    rw.add_argument("--workflow-id", required=True, help="Workflow ID")

    # list-fields
    sub.add_parser("list-fields", help="List custom fields")

    # get-fields
    gf = sub.add_parser("get-fields", help="Get contact's custom field values")
    gf.add_argument("--id", required=True, help="Contact ID")

    # update-fields
    uf = sub.add_parser("update-fields", help="Update custom fields")
    uf.add_argument("--id", required=True, help="Contact ID")
    uf.add_argument("--fields", required=True, help="JSON: {fieldKey: value} or [{id, field_value}]")

    # list-pipelines
    sub.add_parser("list-pipelines", help="List pipelines and stages")

    # add-opportunity
    ao = sub.add_parser("add-opportunity", help="Create a pipeline opportunity")
    ao.add_argument("--data", required=True, help="JSON: {contactId, pipelineId, name, ...}")

    # move-stage
    ms = sub.add_parser("move-stage", help="Move opportunity to different stage")
    ms.add_argument("--id", required=True, help="Opportunity ID")
    ms.add_argument("--stage-id", required=True, help="New pipeline stage ID")

    # send-email
    se = sub.add_parser("send-email", help="Send email to a contact")
    se.add_argument("--id", required=True, help="Contact ID")
    se.add_argument("--subject", required=True, help="Email subject")
    se.add_argument("--body", required=True, help="Email body")

    # send-sms
    ss = sub.add_parser("send-sms", help="Send SMS to a contact")
    ss.add_argument("--id", required=True, help="Contact ID")
    ss.add_argument("--message", required=True, help="SMS message text")

    # bulk-add
    ba = sub.add_parser("bulk-add", help="Add multiple contacts from JSON file")
    ba.add_argument("--file", required=True, help="Path to JSON file with contacts array")

    # bulk-tag
    bt = sub.add_parser("bulk-tag", help="Tag multiple contacts")
    bt.add_argument("--ids", required=True, help="Comma-separated contact IDs")
    bt.add_argument("--tags", required=True, help="Comma-separated tags")

    # bulk-workflow
    bw = sub.add_parser("bulk-workflow", help="Add multiple contacts to a workflow")
    bw.add_argument("--ids", required=True, help="Comma-separated contact IDs")
    bw.add_argument("--workflow-id", required=True, help="Workflow ID")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return

    try:
        if args.command == "test-connection":
            _output(test_connection())

        elif args.command == "save-credentials":
            _output(save_credentials(args.token, args.location_id))

        elif args.command == "list-contacts":
            _output(list_contacts(limit=args.limit))

        elif args.command == "add-contact":
            _output(add_contact(json.loads(args.data)))

        elif args.command == "find-contact":
            _output(find_contact(args.query))

        elif args.command == "get-contact":
            _output(get_contact(args.id))

        elif args.command == "update-contact":
            _output(update_contact(args.id, json.loads(args.data)))

        elif args.command == "delete-contact":
            _output(delete_contact(args.id))

        elif args.command == "add-tag":
            _output(add_tag(args.id, args.tags))

        elif args.command == "remove-tag":
            _output(remove_tag(args.id, args.tags))

        elif args.command == "list-tags":
            _output(list_tags(args.id))

        elif args.command == "trigger-by-tag":
            _output(trigger_by_tag(args.id, args.tag))

        elif args.command == "list-workflows":
            _output(list_workflows())

        elif args.command == "add-to-workflow":
            _output(add_to_workflow(args.id, args.workflow_id))

        elif args.command == "remove-from-workflow":
            _output(remove_from_workflow(args.id, args.workflow_id))

        elif args.command == "list-fields":
            _output(list_fields())

        elif args.command == "get-fields":
            _output(get_fields(args.id))

        elif args.command == "update-fields":
            _output(update_fields(args.id, json.loads(args.fields)))

        elif args.command == "list-pipelines":
            _output(list_pipelines())

        elif args.command == "add-opportunity":
            _output(add_opportunity(json.loads(args.data)))

        elif args.command == "move-stage":
            _output(move_stage(args.id, args.stage_id))

        elif args.command == "send-email":
            _output(send_email(args.id, args.subject, args.body))

        elif args.command == "send-sms":
            _output(send_sms(args.id, args.message))

        elif args.command == "bulk-add":
            with open(args.file) as f:
                contacts = json.loads(f.read())
            _output(bulk_add(contacts))

        elif args.command == "bulk-tag":
            _output(bulk_tag(args.ids, args.tags))

        elif args.command == "bulk-workflow":
            _output(bulk_workflow(args.ids, args.workflow_id))

        else:
            parser.print_help()

    except Exception as exc:
        _output({"error": str(exc)})
        sys.exit(1)


if __name__ == "__main__":
    main()
