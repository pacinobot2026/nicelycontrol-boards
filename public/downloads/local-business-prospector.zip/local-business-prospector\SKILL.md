---
name: Local Business Prospector
slug: local-business-prospector
author: OpenClaw
description: >
  Find local businesses with weak marketing and push them into your sales pipeline. 
  Searches Google Maps via Apify, scores prospects (Hot/Warm/Low), enriches with 
  emails via Hunter.io, and pushes to GoHighLevel. Self-contained — no plugins needed.
version: 3.0.0
requires:
  - python3
  - Apify API key (free at apify.com)
  - Hunter.io API key (free at hunter.io) - optional, for email enrichment
  - GoHighLevel API key (optional, for CRM push)
trigger: /prospect
emoji: 🎯
---

# Local Business Prospector v3

**Trigger:** `/prospect`

**Purpose:** Find local businesses that need marketing help, score them, get their emails, and push to GHL.

---

## Complete User Flow

### Pre-Step — API Key Setup (First Run Only)

**Check Apify API key:**
- If missing: "I need your Apify API key to search Google Maps. Get a free key at https://console.apify.com (takes 30 seconds). Paste it here:"
- Save: `python3 scripts/apify_search.py save-key --key YOUR_KEY`

**Check Hunter.io API key:**
- If missing: "Want me to find email addresses? Get a free Hunter.io key at https://hunter.io (50 searches/month free). Paste it here (or say 'skip'):"
- Save: `python3 scripts/hunter_io.py save-key --key YOUR_KEY`

---

### Step #1 — Ask How Many Leads
"How many leads do you want? (default: 10)"

---

### Step #2 — Ask City/Area
"What city or area?"

---

### Step #3 — Ask Niche
"What type of business?"

---

### Display Basic Report
```
10 Restaurants found
8 Domains found
3 Phone numbers listed
```

---

### Display Detailed Results with Scoring

```
1. Better Days Coffee & Acai
   Score: ⚪ Low
   Type: Coffee shop
   Location: 10595 Discovery Dr, Las Vegas, NV 89135
   Phone: (702) 781-6337
   Website: atbetterdays.com
   Reviews: 208 (4.5⭐)
   Why: Low priority — 208 reviews (well-established), 4.5 stars (strong).

2. Foxtail Coffee - Trails Village Center
   Score: 🟡 Warm
   Type: Coffee shop
   Location: 1990 Village Center Cir Suite 1, Las Vegas, NV 89134
   Phone: (725) 205-0726
   Website: foxtailcoffee.com
   Reviews: 79 (4.1⭐)
   Why: Decent prospect — 79 reviews (moderate), 4.1 stars (below average).

3. Teaspoon Summerlin
   Score: ⚪ Low
   Type: Tea house
   Location: 1990 Village Center Cir Suite 9, Las Vegas, NV 89134
   Phone: (702) 802-2113
   Website: order.teaspoonlife.com
   Reviews: 165 (4.5⭐)
   Why: Low priority — 165 reviews (well-established), 4.5 stars (strong).

🔥 Hot: 0 | 🟡 Warm: 1 | ⚪ Low: 2
```

---

### Step #4 — Ask for Removals
"Are there any leads you want removed? (reply with numbers, or 'none')"

- Remove selected leads
- Update count

---

### Step #5 — Ask for Email Enrichment
"Do you want me to take the [X] domains and retrieve the email addresses?"

**If yes:**
- Run Hunter.io on remaining domains
- Display results:
```
Found 1 email out of 3 domains

✅ Foxtail Coffee Co — jason.stehli@foxtailcoffee.com (99% confidence)
   Position: Operating Partner

❌ Better Days Coffee — No emails found
❌ Teaspoon Summerlin — No emails found
```

---

### Step #6 — Ask for GHL Push
"Should I add these contacts to GoHighLevel?"

**If yes:**
- "Which tag?" (e.g., "coffee-shops", "summerlin-leads")
- "Which workflow?" (optional — skip if unsure)
- **Smart phone handling:** First contact per business gets phone number, additional contacts get email only (prevents duplicate phone errors)
- Push to GHL with tag applied

---

### Step #7 — Create and Send CSV
- Generate CSV with all lead data
- Send to Telegram as downloadable file
- "Here's your CSV file. Click to download."

---

## Scoring Logic

**Hot Lead (Best Prospect):**
- Review count under 50
- Star rating below 4.0 OR no rating
- No website

**Warm Lead:**
- Review count 50–150
- Has website but may be outdated
- Star rating 4.0–4.5

**Low Priority:**
- Review count over 150
- Star rating 4.5+
- Active website with clear branding

---

## Commands

### Save API Keys (First Time Only)
```bash
python3 scripts/apify_search.py save-key --key YOUR_APIFY_KEY
python3 scripts/hunter_io.py save-key --key YOUR_HUNTER_KEY
python3 scripts/ghl_sync.py save-credentials --token "pit-..." --location-id "..."
```

### Test Connections
```bash
python3 scripts/apify_search.py test
python3 scripts/hunter_io.py test
python3 scripts/ghl_sync.py test-connection
```

---

## File Structure

```
local-business-prospector/
├── SKILL.md                          # This file
├── scripts/
│   ├── apify_search.py              # Google Maps search via Apify
│   ├── hunter_io.py                 # Email enrichment via Hunter.io
│   ├── ghl_sync.py                  # GoHighLevel integration
│   └── web_scraper.py               # Fallback scraper (no API needed)
└── references/
    ├── outreach-templates.md        # Email/SMS templates
    └── ghl-api-reference.md         # GHL API docs
```

---

## API Keys Storage

Keys stored in `~/.local-business-prospector/`:
- `apify_key` — Apify API key
- `hunter_io_key` — Hunter.io API key
- `ghl_token` — GHL token
- `ghl_location_id` — GHL location

---

## Cost

- **Apify** — Free tier: $5/month credit (~500 searches)
- **Hunter.io** — Free tier: 50 searches/month
- **GoHighLevel** — Your existing subscription

---

## Troubleshooting

| Error | Solution |
|-------|----------|
| "Apify API key not found" | Run: `python3 scripts/apify_search.py save-key --key YOUR_KEY` |
| "Hunter.io API key not found" | Run: `python3 scripts/hunter_io.py save-key --key YOUR_KEY` |
| "No businesses found" | Try broadening location or different business type |
| "GHL push failed" | Check token has contact write permissions |

---

## Example Session

```
/prospect

[Pre-Step]
> I need your Apify API key...
> apify_api_xxx
✅ Apify API key saved!

> Want me to find email addresses?
> hunter_api_xxx
✅ Hunter.io API key saved!

[Step #1]
> How many leads? 3

[Step #2]
> What city? Summerlin, NV

[Step #3]
> What niche? Coffee Shops

[Results]
3 Coffee Shops found
3 Domains found
3 Phone numbers listed

1. Better Days Coffee & Acai
   Score: ⚪ Low
   ...

2. Foxtail Coffee
   Score: 🟡 Warm
   ...

[Step #4]
> Any leads to remove? none

[Step #5]
> Retrieve email addresses? yes
Found 1 email out of 3 domains
✅ jason.stehli@foxtailcoffee.com

[Step #6]
> Add to GoHighLevel? yes
> Which tag? coffee-shops
> Which workflow? skip
✅ Pushed to GHL

[Step #7]
📎 leads-2026-04-22.csv
```