import urllib.request
import urllib.parse
import json
import ssl

BASE_URL = 'https://services.leadconnectorhq.com'
API_VERSION = '2021-07-28'

# Get credentials
with open('C:/Users/Administrator/.local-business-prospector/ghl_token', 'r') as f:
    token = f.read().strip()
with open('C:/Users/Administrator/.local-business-prospector/ghl_location_id', 'r') as f:
    location_id = f.read().strip()

# SSL context
ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

# Get workflows
url = f'{BASE_URL}/workflows/?locationId={urllib.parse.quote(location_id)}'
req = urllib.request.Request(url, headers={
    'Authorization': f'Bearer {token}',
    'Version': API_VERSION,
    'Accept': 'application/json'
})

with urllib.request.urlopen(req, context=ctx) as resp:
    data = json.loads(resp.read().decode('utf-8'))
    workflows = data.get('workflows', [])
    print(f'Found {len(workflows)} workflows:')
    for wf in workflows[:10]:
        name = wf.get('name', 'Unnamed')
        wf_id = wf.get('id', 'N/A')
        print(f'  - {name} (ID: {wf_id})')