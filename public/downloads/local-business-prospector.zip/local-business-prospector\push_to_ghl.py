#!/usr/bin/env python3
"""Quick wrapper to push contacts to GHL using ghl-workflow skill"""
import sys
import os
import subprocess
import json

# Path to ghl-workflow skill
GHL_SKILL_PATH = r"C:\Users\Administrator\.openclaw\skills\ghl-workflow"
GHL_SCRIPT = os.path.join(GHL_SKILL_PATH, "scripts", "ghl_workflow.py")

def push_contact(email, first_name, last_name, phone, company, tags):
    """Push a single contact to GHL with tags"""
    data = {
        "firstName": first_name,
        "lastName": last_name,
        "email": email,
        "companyName": company,
        "tags": tags if isinstance(tags, list) else [tags]
    }
    
    # Only add phone if provided (avoid duplicate phone number errors)
    if phone and phone != "None" and phone != "":
        data["phone"] = phone
    
    # Write to temp file
    temp_file = "temp_contact.json"
    with open(temp_file, 'w') as f:
        json.dump(data, f)
    
    try:
        # Call ghl_workflow.py with file input
        result = subprocess.run(
            ["python", GHL_SCRIPT, "add-contact", "--data", json.dumps(data)],
            capture_output=True,
            text=True
        )
        
        if result.returncode == 0:
            return json.loads(result.stdout)
        else:
            return {"error": result.stderr}
    finally:
        if os.path.exists(temp_file):
            os.remove(temp_file)

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 7:
        print("Usage: python push_to_ghl.py EMAIL FIRST LAST PHONE COMPANY TAG")
        sys.exit(1)
    
    email = sys.argv[1]
    first_name = sys.argv[2]
    last_name = sys.argv[3]
    phone = sys.argv[4]
    company = sys.argv[5]
    tag = sys.argv[6]
    
    result = push_contact(email, first_name, last_name, phone, company, tag)
    print(json.dumps(result, indent=2))
