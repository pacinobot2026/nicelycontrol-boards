# GoHighLevel API Reference

This document outlines the GoHighLevel (GHL) API endpoints used by the Local Business Prospector skill. The integration relies on the GHL v2.0 API using Private Integration Tokens.

## Authentication

All requests to the GHL API require a Private Integration Token and a specific API version header.

**Base URL:** `https://services.leadconnectorhq.com`
**Headers:**
- `Authorization: Bearer {GHL_PRIVATE_TOKEN}`
- `Version: 2021-07-28`
- `Content-Type: application/json`
- `Accept: application/json`

## Contacts API

The Contacts API is used to create and manage leads found by the prospector.

### Create Contact

Creates a new contact in the specified location.

**Endpoint:** `POST /contacts/`

**Request Body:**
```json
{
  "locationId": "string",
  "firstName": "string",
  "lastName": "string",
  "name": "string",
  "companyName": "string",
  "phone": "string",
  "email": "string",
  "address1": "string",
  "city": "string",
  "state": "string",
  "postalCode": "string",
  "website": "string",
  "tags": ["string"],
  "source": "Local Business Prospector"
}
```

**Response (201 Created):**
Returns a contact object containing the generated `id`, which is required for creating opportunities.

### List Contacts

Retrieves a list of contacts for a location.

**Endpoint:** `GET /contacts/?locationId={LOCATION_ID}&limit={LIMIT}`

**Response (200 OK):**
Returns an object with a `contacts` array and `meta` pagination details.

### Delete Contact

Deletes a contact by ID. Used primarily for testing and cleanup.

**Endpoint:** `DELETE /contacts/{contactId}`

**Response (200 OK):**
Returns `{ "succeded": true }`.

## Pipelines & Opportunities API

The Pipelines API is used to track the status of leads through the sales process.

### List Pipelines

Retrieves all pipelines for a location.

**Endpoint:** `GET /opportunities/pipelines?locationId={LOCATION_ID}`

**Response (200 OK):**
Returns an object with a `pipelines` array. Each pipeline contains an array of `stages` with their respective IDs.

### Create Pipeline

Creates a new pipeline with specified stages. The skill creates a "Local Business Prospector" pipeline if it doesn't exist.

**Endpoint:** `POST /opportunities/pipelines`

**Request Body:**
```json
{
  "locationId": "string",
  "name": "Local Business Prospector",
  "stages": [
    { "name": "New Lead", "position": 0 },
    { "name": "Contacted", "position": 1 },
    { "name": "Responded", "position": 2 },
    { "name": "Meeting Set", "position": 3 },
    { "name": "Closed Won", "position": 4 },
    { "name": "Closed Lost", "position": 5 }
  ]
}
```

**Response (201 Created):**
Returns the created pipeline object, including the generated IDs for the pipeline and its stages.

### Create Opportunity

Adds a contact to a specific stage in a pipeline.

**Endpoint:** `POST /opportunities/`

**Request Body:**
```json
{
  "pipelineId": "string",
  "pipelineStageId": "string",
  "locationId": "string",
  "contactId": "string",
  "name": "string",
  "status": "open",
  "monetaryValue": 0
}
```

**Response (201 Created):**
Returns the created opportunity object.

## Error Handling

The GHL API uses standard HTTP status codes:
- **400 Bad Request:** Invalid input data (e.g., missing required fields).
- **401 Unauthorized:** Invalid or expired token.
- **429 Too Many Requests:** Rate limit exceeded. The script implements exponential backoff for retries.
- **500 Internal Server Error:** GHL server issue. The script will retry these requests.
