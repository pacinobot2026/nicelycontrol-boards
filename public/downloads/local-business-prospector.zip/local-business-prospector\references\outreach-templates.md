# Outreach Templates

This document contains email and SMS templates for reaching out to local businesses identified by the Local Business Prospector skill. These templates are designed to be personalized based on the specific weaknesses found during the prospecting phase.

## Email Templates

### Template 1: The "Low Reviews" Angle

**Subject:** Quick question about {{Business Name}}'s online presence

Hi {{First Name}},

I was looking for a {{Business Type}} in {{Location}} today and came across {{Business Name}}. I noticed you only have {{Review Count}} reviews on Google, while some of your competitors have over 100.

In my experience working with local businesses, having fewer reviews often means you're missing out on a significant amount of local search traffic. People tend to click on the businesses with the most reviews first.

I have a simple system that helps businesses like yours automatically collect more 5-star reviews from happy customers. Would you be open to a quick 5-minute chat to see how it works?

Best regards,
{{Your Name}}

### Template 2: The "No Website" Angle

**Subject:** Reaching customers for {{Business Name}}

Hi {{First Name}},

I was trying to find more information about {{Business Name}} online today, but I couldn't find a website for your business.

Many potential customers in {{Location}} search online before deciding which {{Business Type}} to visit. Without a website, it's harder for them to find your hours, services, and contact information, which means they might choose a competitor instead.

I specialize in building simple, effective websites for local businesses that turn visitors into customers. I'd love to show you a quick mockup of what a site for {{Business Name}} could look like.

Are you available for a brief call next week?

Best,
{{Your Name}}

### Template 3: The "Weak Social Media" Angle

**Subject:** Ideas for {{Business Name}}'s social media

Hi {{First Name}},

I came across {{Business Name}} while researching {{Business Type}}s in {{Location}}. You have a great business, but I noticed your social media presence hasn't been updated recently.

Consistent social media posting is one of the best ways to stay top-of-mind with your local community and attract new customers. However, I know it can be time-consuming to manage while running a business.

I help local businesses create and schedule engaging social media content automatically. I've put together a few ideas specifically for {{Business Name}} that I think would perform really well.

Would you be interested in seeing them?

Thanks,
{{Your Name}}

## SMS Templates

### SMS 1: General Outreach

Hi {{First Name}}, this is {{Your Name}}. I was looking at {{Business Name}} online and noticed a few quick ways you could get more customers from Google. Do you have 5 mins for a quick chat this week?

### SMS 2: Review Focus

Hi {{First Name}}, I noticed {{Business Name}} only has {{Review Count}} reviews on Google. I help local businesses get more 5-star reviews automatically. Open to a quick chat about how it works? - {{Your Name}}

### SMS 3: Website Focus

Hi {{First Name}}, I was trying to find {{Business Name}}'s website but couldn't locate one. I build simple sites for local businesses to help them get found online. Interested in seeing a quick mockup? - {{Your Name}}

## Best Practices for Outreach

1. **Personalize:** Always use the business name and the owner's name if available.
2. **Be Specific:** Mention the exact weakness you found (e.g., "only 12 reviews").
3. **Keep it Short:** Business owners are busy. Get straight to the point.
4. **Clear Call to Action:** End with a simple, low-friction question (e.g., "Open to a quick chat?").
5. **Follow Up:** Don't give up after one message. Send a polite follow-up a few days later.
