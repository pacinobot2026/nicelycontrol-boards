#!/usr/bin/env python3
"""
apify_search.py - Search for local businesses using Apify API
Uses direct HTTP API calls - no Node.js required.

Usage:
    python3 apify_search.py search --type "restaurants" --location "Las Vegas" --count 10
"""

import urllib.request
import urllib.error
import urllib.parse
import json
import sys
import os
import ssl
import time
import argparse

# Apify API Configuration
BASE_URL = "https://api.apify.com/v2"
USER_AGENT = "local-business-prospector/3.0"

# Actor IDs
GOOGLE_PLACES_ACTOR = "compass~crawler-google-places"

# SSL context
SSL_CTX = ssl.create_default_context()
SSL_CTX.check_hostname = False
SSL_CTX.verify_mode = ssl.CERT_NONE

# Retry settings
MAX_RETRIES = 3
RETRY_DELAY = 2
REQUEST_TIMEOUT = 30


def get_api_key():
    """Get Apify API key from environment or config file."""
    # Check environment variable first
    api_key = os.environ.get("APIFY_TOKEN", "")
    
    # Check config file
    if not api_key:
        config_path = os.path.expanduser("~/.local-business-prospector/apify_key")
        if os.path.isfile(config_path):
            with open(config_path, 'r') as f:
                api_key = f.read().strip()
    
    return api_key


def save_api_key(api_key):
    """Save Apify API key to config file."""
    config_dir = os.path.expanduser("~/.local-business-prospector")
    os.makedirs(config_dir, exist_ok=True)
    
    with open(os.path.join(config_dir, "apify_key"), 'w') as f:
        f.write(api_key)
    
    return True


def make_request(url, method="GET", data=None, headers=None):
    """Make HTTP request with retries."""
    default_headers = {
        "User-Agent": USER_AGENT,
        "Accept": "application/json",
    }
    if headers:
        default_headers.update(headers)
    
    for attempt in range(MAX_RETRIES):
        try:
            req = urllib.request.Request(
                url, 
                data=data.encode('utf-8') if data else None,
                headers=default_headers,
                method=method
            )
            with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT, context=SSL_CTX) as resp:
                return json.loads(resp.read().decode('utf-8'))
        except urllib.error.HTTPError as e:
            if e.code == 429 and attempt < MAX_RETRIES - 1:
                time.sleep(RETRY_DELAY * (attempt + 1))
                continue
            raise
        except Exception as e:
            if attempt < MAX_RETRIES - 1:
                time.sleep(RETRY_DELAY * (attempt + 1))
                continue
            raise


def start_actor_run(actor_id, input_data):
    """Start an Apify actor run."""
    api_key = get_api_key()
    if not api_key:
        raise RuntimeError(
            "Apify API key not found. "
            "Set APIFY_TOKEN environment variable or run: "
            "python3 apify_search.py save-key --key YOUR_API_KEY"
        )
    
    # Convert actor ID format: compass/crawler-google-places -> compass~crawler-google-places
    api_actor_id = actor_id.replace("/", "~")
    url = f"{BASE_URL}/acts/{api_actor_id}/runs?token={urllib.parse.quote(api_key)}"
    
    headers = {"Content-Type": "application/json"}
    response = make_request(url, method="POST", data=json.dumps(input_data), headers=headers)
    
    return {
        "runId": response["data"]["id"],
        "datasetId": response["data"]["defaultDatasetId"],
    }


def poll_run_status(run_id, timeout=600, interval=5):
    """Poll actor run until completion."""
    api_key = get_api_key()
    url = f"{BASE_URL}/actor-runs/{run_id}?token={urllib.parse.quote(api_key)}"
    start_time = time.time()
    last_status = None
    
    while True:
        result = make_request(url)
        status = result["data"]["status"]
        
        if status != last_status:
            print(f"Status: {status}", file=sys.stderr)
            last_status = status
        
        if status in ["SUCCEEDED", "FAILED", "ABORTED", "TIMED-OUT"]:
            return status
        
        elapsed = time.time() - start_time
        if elapsed > timeout:
            print(f"Warning: Timeout after {timeout}s", file=sys.stderr)
            return "TIMED-OUT"
        
        time.sleep(interval)


def download_results(dataset_id):
    """Download results from dataset."""
    api_key = get_api_key()
    url = f"{BASE_URL}/datasets/{dataset_id}/items?token={urllib.parse.quote(api_key)}&format=json"
    return make_request(url)


def score_lead(biz):
    """Score a business lead."""
    reviews = biz.get("reviewsCount", 0) or 0
    rating = biz.get("totalScore", 0.0) or 0.0
    has_website = bool(biz.get("website"))
    reasons = []
    
    hot_signals = 0
    warm_signals = 0
    low_signals = 0
    
    # Review count (strongest signal)
    if reviews < 50:
        hot_signals += 2
        reasons.append(f"Only {reviews} reviews")
    elif reviews <= 150:
        warm_signals += 1
        reasons.append(f"{reviews} reviews (moderate)")
    else:
        low_signals += 2
        reasons.append(f"{reviews} reviews (well-established)")
    
    # Website presence
    if not has_website:
        hot_signals += 1
        reasons.append("no website")
    else:
        warm_signals += 0.5
    
    # Star rating
    if rating == 0.0:
        hot_signals += 0.5
        reasons.append("no rating data")
    elif rating < 4.0:
        hot_signals += 1
        reasons.append(f"{rating} stars (below average)")
    elif rating <= 4.5:
        warm_signals += 0.5
    else:
        low_signals += 1
        reasons.append(f"{rating} stars (strong)")
    
    # Determine final score
    if hot_signals >= 2:
        label = "Hot"
        emoji = "🔥"
        reason_prefix = "Great prospect"
    elif warm_signals >= 1 and hot_signals >= 1:
        label = "Warm"
        emoji = "🟡"
        reason_prefix = "Decent prospect"
    elif low_signals >= 2:
        label = "Low"
        emoji = "⚪"
        reason_prefix = "Low priority"
    else:
        label = "Warm"
        emoji = "🟡"
        reason_prefix = "Moderate prospect"
    
    reason = f"{reason_prefix} — {', '.join(reasons)}."
    return label, emoji, reason


def format_results(results, business_type, location):
    """Format results for display."""
    if not results:
        return "No businesses found. Try broadening the location or simplifying the business type."
    
    # Score and sort results
    scored_results = []
    for biz in results:
        label, emoji, reason = score_lead(biz)
        biz["score_label"] = label
        biz["score_emoji"] = emoji
        biz["score_reason"] = reason
        scored_results.append(biz)
    
    # Sort: Hot first, then Warm, then Low
    priority = {"Hot": 0, "Warm": 1, "Low": 2}
    scored_results.sort(key=lambda b: (priority.get(b["score_label"], 9), b.get("reviewsCount", 999)))
    
    lines = []
    for i, biz in enumerate(scored_results, 1):
        lines.append(f"{i}. {biz.get('title', 'Unknown')}")
        lines.append(f"   Score: {biz['score_emoji']} {biz['score_label']}")
        lines.append(f"   Type: {biz.get('categoryName', business_type)}")
        lines.append(f"   Location: {biz.get('address', 'Not listed')}")
        lines.append(f"   Phone: {biz.get('phone', 'Not listed')}")
        lines.append(f"   Website: {biz.get('website') or 'None'}")
        rating_str = f"{biz.get('totalScore', 0)}⭐" if biz.get('totalScore') else "N/A"
        lines.append(f"   Reviews: {biz.get('reviewsCount', 0)} ({rating_str})")
        lines.append(f"   Why: {biz['score_reason']}")
        lines.append("")
    
    return "\n".join(lines)


def search_businesses(business_type, location, count=10):
    """Search for local businesses using Apify."""
    print(f"Starting search for {count} {business_type} in {location}...", file=sys.stderr)
    
    # Prepare input for Google Places actor
    input_data = {
        "searchStringsArray": [business_type],
        "locationQuery": location,
        "maxCrawledPlacesPerSearch": count,
        "language": "en",
        "skipClosedPlaces": True,
    }
    
    # Start actor run
    run_info = start_actor_run("compass/crawler-google-places", input_data)
    print(f"Run ID: {run_info['runId']}", file=sys.stderr)
    print(f"Dataset ID: {run_info['datasetId']}", file=sys.stderr)
    
    # Poll for completion
    status = poll_run_status(run_info['runId'])
    
    if status != "SUCCEEDED":
        print(f"Error: Actor run {status}", file=sys.stderr)
        return []
    
    # Download results
    results = download_results(run_info['datasetId'])
    print(f"Found {len(results)} businesses", file=sys.stderr)
    
    return results


def main():
    parser = argparse.ArgumentParser(description="Local Business Prospector - Apify Search")
    parser.add_argument("--type", required=True, help="Business type (e.g., restaurants, dentists)")
    parser.add_argument("--location", required=True, help="City/area (e.g., 'Las Vegas, USA')")
    parser.add_argument("--count", type=int, default=10, help="Number of results (default: 10)")
    parser.add_argument("--format", default="text", choices=["text", "json"], help="Output format")
    parser.add_argument("--output", help="Output file path")
    parser.add_argument("--enrich-emails", action="store_true", help="Enrich leads with emails from Hunter.io")
    
    args = parser.parse_args()
    
    # Search for businesses
    results = search_businesses(args.type, args.location, args.count)
    
    # Enrich with emails if requested
    if args.enrich_emails and results:
        print("Enriching leads with emails from Hunter.io...", file=sys.stderr)
        from hunter_io import enrich_leads_with_emails
        results = enrich_leads_with_emails(results)
    
    # Format output
    if args.format == "json":
        output = json.dumps(results, indent=2, ensure_ascii=False)
    else:
        output = format_results(results, args.type, args.location)
    
    # Save or print
    if args.output:
        with open(args.output, 'w', encoding='utf-8') as f:
            f.write(output)
        print(f"Saved to: {args.output}")
    else:
        # Fix Windows console encoding
        import sys
        if sys.platform == 'win32':
            import io
            sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
        print(output)


def test_connection():
    """Test Apify API connection."""
    try:
        api_key = get_api_key()
        if not api_key:
            return {"status": "error", "message": "No API key configured"}
        
        # Test by listing actors (lightweight call)
        url = f"{BASE_URL}/acts?token={urllib.parse.quote(api_key)}&limit=1"
        make_request(url)
        return {"status": "connected", "message": "Apify API connection successful"}
    except Exception as e:
        return {"status": "error", "message": str(e)}


if __name__ == "__main__":
    # Check if first arg is a command
    if len(sys.argv) > 1 and sys.argv[1] in ("save-key", "test"):
        if sys.argv[1] == "save-key":
            # Parse --key argument
            key = None
            for i, arg in enumerate(sys.argv):
                if arg == "--key" and i + 1 < len(sys.argv):
                    key = sys.argv[i + 1]
                    break
            if key:
                save_api_key(key)
                print("API key saved successfully!")
            else:
                print("Usage: python3 apify_search.py save-key --key YOUR_API_KEY")
                sys.exit(1)
        elif sys.argv[1] == "test":
            result = test_connection()
            print(json.dumps(result, indent=2))
    else:
        main()