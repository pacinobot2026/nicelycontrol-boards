#!/usr/bin/env python3
"""
ghl_sync.py — GoHighLevel API wrapper for Local Business Prospector
Uses only Python standard library (urllib, json).
No pip installs required.

Environment variables:
    GHL_PRIVATE_TOKEN  — Private Integration Token (pit-...)
    GHL_LOCATION_ID    — Location ID

Usage:
    python3 ghl_sync.py test-connection
    python3 ghl_sync.py create-contact --data '{"firstName":"John","lastName":"Doe","phone":"+15551234567"}'
    python3 ghl_sync.py create-pipeline
    python3 ghl_sync.py push-leads --file leads.json
    python3 ghl_sync.py list-contacts
    python3 ghl_sync.py delete-contact --id "abc123"
"""

import urllib.request
import urllib.error
import urllib.parse
import json
import sys
import os
import ssl
import time
import argparse

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

BASE_URL = "https://services.leadconnectorhq.com"
API_VERSION = "2021-07-28"

PIPELINE_NAME = "Local Business Prospector"
PIPELINE_STAGES = [
    {"name": "New Lead", "position": 0},
    {"name": "Contacted", "position": 1},
    {"name": "Responded", "position": 2},
    {"name": "Meeting Set", "position": 3},
    {"name": "Closed Won", "position": 4},
    {"name": "Closed Lost", "position": 5},
]

SOURCE_NAME = "Local Business Prospector"

MAX_RETRIES = 3
RETRY_DELAY = 2
REQUEST_TIMEOUT = 20

# SSL context
SSL_CTX = ssl.create_default_context()
SSL_CTX.check_hostname = False
SSL_CTX.verify_mode = ssl.CERT_NONE


# ---------------------------------------------------------------------------
# Credential helpers
# ---------------------------------------------------------------------------

def _get_token():
    """Get GHL Private Integration Token from env or config file."""
    token = os.environ.get("GHL_PRIVATE_TOKEN", "")
    if not token:
        config_path = os.path.expanduser("~/.local-business-prospector/ghl_token")
        if os.path.isfile(config_path):
            with open(config_path) as f:
                token = f.read().strip()
    if not token:
        raise RuntimeError(
            "GHL_PRIVATE_TOKEN not set. "
            "Export it: export GHL_PRIVATE_TOKEN='pit-...'"
        )
    return token


def _get_location_id():
    """Get GHL Location ID from env or config file."""
    loc_id = os.environ.get("GHL_LOCATION_ID", "")
    if not loc_id:
        config_path = os.path.expanduser("~/.local-business-prospector/ghl_location_id")
        if os.path.isfile(config_path):
            with open(config_path) as f:
                loc_id = f.read().strip()
    if not loc_id:
        raise RuntimeError(
            "GHL_LOCATION_ID not set. "
            "Export it: export GHL_LOCATION_ID='your-location-id'"
        )
    return loc_id


def save_credentials(token, location_id):
    """Save GHL credentials to config files for persistence."""
    config_dir = os.path.expanduser("~/.local-business-prospector")
    os.makedirs(config_dir, exist_ok=True)
    with open(os.path.join(config_dir, "ghl_token"), "w") as f:
        f.write(token)
    with open(os.path.join(config_dir, "ghl_location_id"), "w") as f:
        f.write(location_id)
    # Also export to current environment
    os.environ["GHL_PRIVATE_TOKEN"] = token
    os.environ["GHL_LOCATION_ID"] = location_id


# ---------------------------------------------------------------------------
# HTTP helpers
# ---------------------------------------------------------------------------

def _request(method, path, body=None, retries=MAX_RETRIES):
    """
    Make an authenticated request to the GHL API.
    Returns parsed JSON response.
    """
    token = _get_token()
    url = f"{BASE_URL}{path}"

    headers = {
        "Authorization": f"Bearer {token}",
        "Version": API_VERSION,
        "Content-Type": "application/json",
        "Accept": "application/json",
        "User-Agent": "LocalBusinessProspector/3.0",
    }

    data = json.dumps(body).encode("utf-8") if body else None

    for attempt in range(retries):
        try:
            req = urllib.request.Request(url, data=data, headers=headers, method=method)
            with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT, context=SSL_CTX) as resp:
                resp_body = resp.read().decode("utf-8")
                return json.loads(resp_body) if resp_body else {}
        except urllib.error.HTTPError as exc:
            error_body = ""
            try:
                error_body = exc.read().decode("utf-8")
            except Exception:
                pass
            if exc.code == 429:
                # Rate limited — wait and retry
                wait = RETRY_DELAY * (attempt + 1) * 2
                time.sleep(wait)
                continue
            elif exc.code >= 500 and attempt < retries - 1:
                time.sleep(RETRY_DELAY * (attempt + 1))
                continue
            else:
                raise RuntimeError(
                    f"GHL API error {exc.code} {method} {path}: {error_body}"
                ) from exc
        except (urllib.error.URLError, OSError) as exc:
            if attempt < retries - 1:
                time.sleep(RETRY_DELAY * (attempt + 1))
            else:
                raise RuntimeError(f"Network error {method} {path}: {exc}") from exc


# ---------------------------------------------------------------------------
# Contact operations
# ---------------------------------------------------------------------------

def create_contact(contact_data):
    """
    Create a contact in GHL.
    
    Args:
        contact_data: dict with keys like firstName, lastName, phone, email,
                      address1, city, state, postalCode, website, tags, etc.
    
    Returns:
        Created contact dict with id.
    """
    location_id = _get_location_id()
    
    payload = {
        "locationId": location_id,
        "source": SOURCE_NAME,
    }
    
    # Map common fields
    field_map = {
        "firstName": "firstName",
        "lastName": "lastName",
        "name": "name",
        "phone": "phone",
        "email": "email",
        "address1": "address1",
        "city": "city",
        "state": "state",
        "postalCode": "postalCode",
        "website": "website",
        "tags": "tags",
        "companyName": "companyName",
    }
    
    for src, dst in field_map.items():
        if src in contact_data and contact_data[src]:
            payload[dst] = contact_data[src]
    
    # Ensure tags is a list
    if "tags" in payload and isinstance(payload["tags"], str):
        payload["tags"] = [payload["tags"]]
    
    result = _request("POST", "/contacts/", body=payload)
    return result.get("contact", result)


def list_contacts(limit=20):
    """List contacts in the location."""
    location_id = _get_location_id()
    result = _request("GET", f"/contacts/?locationId={location_id}&limit={limit}")
    return result.get("contacts", [])


def search_contacts(query="", limit=20):
    """Search contacts by query."""
    location_id = _get_location_id()
    payload = {
        "locationId": location_id,
        "page": 1,
        "pageLimit": limit,
    }
    if query:
        payload["query"] = query
    result = _request("POST", "/contacts/search", body=payload)
    return result.get("contacts", [])


def delete_contact(contact_id):
    """Delete a contact by ID."""
    result = _request("DELETE", f"/contacts/{contact_id}")
    return result


def get_contact(contact_id):
    """Get a single contact by ID."""
    result = _request("GET", f"/contacts/{contact_id}")
    return result.get("contact", result)


# ---------------------------------------------------------------------------
# Pipeline operations
# ---------------------------------------------------------------------------

def list_pipelines():
    """List all pipelines in the location."""
    location_id = _get_location_id()
    result = _request("GET", f"/opportunities/pipelines?locationId={location_id}")
    return result.get("pipelines", [])


def find_or_create_pipeline():
    """
    Find the 'Local Business Prospector' pipeline, or create it.
    Returns (pipeline_id, stages_dict) where stages_dict maps stage name to stage id.
    """
    pipelines = list_pipelines()
    
    # Check if our pipeline already exists
    for p in pipelines:
        if p.get("name") == PIPELINE_NAME:
            stages = {}
            for stage in p.get("stages", []):
                stages[stage["name"]] = stage["id"]
            return p["id"], stages
    
    # Create the pipeline
    location_id = _get_location_id()
    payload = {
        "locationId": location_id,
        "name": PIPELINE_NAME,
        "stages": PIPELINE_STAGES,
    }
    try:
        result = _request("POST", "/opportunities/pipelines", body=payload)
    except RuntimeError as exc:
        if "401" in str(exc) or "not authorized" in str(exc).lower():
            raise RuntimeError(
                "Your GHL token does not have permission to create pipelines. "
                "Please create a pipeline named 'Local Business Prospector' manually "
                "in GHL with stages: New Lead, Contacted, Responded, Meeting Set, "
                "Closed Won, Closed Lost. Then re-run this command."
            ) from exc
        raise
    pipeline = result.get("pipeline", result)
    pipeline_id = pipeline.get("id", "")
    
    stages = {}
    for stage in pipeline.get("stages", []):
        stages[stage["name"]] = stage["id"]
    
    return pipeline_id, stages


# ---------------------------------------------------------------------------
# Opportunity operations
# ---------------------------------------------------------------------------

def create_opportunity(contact_id, contact_name, pipeline_id, stage_id, monetary_value=0):
    """
    Create an opportunity in a pipeline for a contact.
    
    Args:
        contact_id: GHL contact ID
        contact_name: Display name for the opportunity
        pipeline_id: Pipeline ID
        stage_id: Pipeline stage ID
        monetary_value: Optional monetary value
    
    Returns:
        Created opportunity dict.
    """
    location_id = _get_location_id()
    payload = {
        "pipelineId": pipeline_id,
        "pipelineStageId": stage_id,
        "locationId": location_id,
        "contactId": contact_id,
        "name": contact_name,
        "status": "open",
    }
    if monetary_value:
        payload["monetaryValue"] = monetary_value
    
    result = _request("POST", "/opportunities/", body=payload)
    return result.get("opportunity", result)


# ---------------------------------------------------------------------------
# High-level: Push leads to GHL
# ---------------------------------------------------------------------------

def push_leads(leads):
    """
    Push a list of scored leads to GHL.
    Creates contacts, ensures pipeline exists, and creates opportunities.
    
    Args:
        leads: list of dicts from web_scraper or Apify results.
               Expected keys: name, phone, email, address, website,
                              rating, reviews_count, score_label, category, location_query
    
    Returns:
        dict with summary: {created: int, failed: int, pipeline_id: str, details: [...]}
    """
    # Ensure pipeline exists (may fail if token lacks pipeline permissions)
    pipeline_id = ""
    stages = {}
    new_lead_stage_id = ""
    try:
        pipeline_id, stages = find_or_create_pipeline()
        new_lead_stage_id = stages.get("New Lead", "")
    except RuntimeError as exc:
        # Pipeline creation not authorized — continue without opportunities
        pipeline_id = ""
        new_lead_stage_id = ""
    
    created = 0
    failed = 0
    details = []
    
    for lead in leads:
        try:
            # Build tags
            tags = [SOURCE_NAME]
            # Handle both 'category' (scraper) and 'categoryName' (Apify)
            category = lead.get("category") or lead.get("categoryName", "")
            if category:
                tags.append(category)
            if lead.get("location_query"):
                tags.append(lead["location_query"])
            score = lead.get("score_label", "Warm")
            tags.append(f"score:{score.lower()}")
            
            # Parse name into first/last (handle both 'name' and 'title' from Apify)
            name = lead.get("name") or lead.get("title", "Unknown Business")
            name_parts = name.split(None, 1)
            first_name = name_parts[0] if name_parts else name
            last_name = name_parts[1] if len(name_parts) > 1 else ""
            
            # Parse address (handle both 'address' and 'address' from Apify)
            address = lead.get("address", "") or lead.get("address", "") or ""
            address_parts = [p.strip() for p in address.split(",")]
            
            contact_data = {
                "firstName": first_name,
                "lastName": last_name,
                "name": name,
                "companyName": name,
                "phone": lead.get("phone", ""),
                "email": lead.get("email", ""),
                "address1": address_parts[0] if address_parts else "",
                "city": address_parts[1] if len(address_parts) > 1 else "",
                "state": address_parts[2] if len(address_parts) > 2 else "",
                "postalCode": address_parts[3] if len(address_parts) > 3 else "",
                "website": lead.get("website", ""),
                "tags": tags,
            }
            
            # Remove empty string values to avoid API issues
            contact_data = {k: v for k, v in contact_data.items() if v}
            contact_data["tags"] = tags  # Always include tags
            
            # Create contact
            contact = create_contact(contact_data)
            contact_id = contact.get("id", "")
            
            if not contact_id:
                failed += 1
                details.append({"name": name, "status": "failed", "error": "No contact ID returned"})
                continue
            
            # Create opportunity in pipeline
            opp_name = f"{name} — {lead.get('category', 'Lead')}"
            if new_lead_stage_id:
                try:
                    create_opportunity(contact_id, opp_name, pipeline_id, new_lead_stage_id)
                except Exception as opp_err:
                    # Contact created but opportunity failed — still count as partial success
                    details.append({
                        "name": name,
                        "status": "partial",
                        "contact_id": contact_id,
                        "error": f"Opportunity creation failed: {opp_err}"
                    })
                    created += 1
                    continue
            
            created += 1
            details.append({
                "name": name,
                "status": "success",
                "contact_id": contact_id,
            })
            
            # Small delay to avoid rate limits
            time.sleep(0.3)
            
        except Exception as exc:
            failed += 1
            details.append({
                "name": lead.get("name", "Unknown"),
                "status": "failed",
                "error": str(exc),
            })
    
    return {
        "created": created,
        "failed": failed,
        "total": len(leads),
        "pipeline_id": pipeline_id,
        "details": details,
    }


# ---------------------------------------------------------------------------
# Connection test
# ---------------------------------------------------------------------------

def test_connection():
    """
    Test the GHL API connection by listing contacts.
    Returns True if successful, raises on failure.
    """
    try:
        contacts = list_contacts(limit=1)
        return {
            "status": "connected",
            "message": "GHL API connection successful.",
            "location_id": _get_location_id(),
        }
    except Exception as exc:
        return {
            "status": "error",
            "message": str(exc),
        }


# ---------------------------------------------------------------------------
# CLI interface
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="GoHighLevel API wrapper for Local Business Prospector"
    )
    sub = parser.add_subparsers(dest="command")

    # test-connection
    sub.add_parser("test-connection", help="Test GHL API connection")

    # create-contact
    cc = sub.add_parser("create-contact", help="Create a single contact")
    cc.add_argument("--data", required=True, help="JSON string with contact data")

    # list-contacts
    lc = sub.add_parser("list-contacts", help="List contacts")
    lc.add_argument("--limit", type=int, default=20, help="Max contacts to return")

    # delete-contact
    dc = sub.add_parser("delete-contact", help="Delete a contact")
    dc.add_argument("--id", required=True, help="Contact ID to delete")

    # create-pipeline
    sub.add_parser("create-pipeline", help="Create or find the prospector pipeline")

    # push-leads
    pl = sub.add_parser("push-leads", help="Push leads from JSON file to GHL")
    pl.add_argument("--file", required=True, help="Path to JSON file with leads array")

    # save-credentials
    sc = sub.add_parser("save-credentials", help="Save GHL credentials")
    sc.add_argument("--token", required=True, help="GHL Private Integration Token")
    sc.add_argument("--location-id", required=True, help="GHL Location ID")

    args = parser.parse_args()

    if args.command == "test-connection":
        result = test_connection()
        print(json.dumps(result, indent=2))

    elif args.command == "create-contact":
        data = json.loads(args.data)
        result = create_contact(data)
        print(json.dumps(result, indent=2))

    elif args.command == "list-contacts":
        result = list_contacts(limit=args.limit)
        print(json.dumps(result, indent=2))

    elif args.command == "delete-contact":
        result = delete_contact(args.id)
        print(json.dumps(result, indent=2))

    elif args.command == "create-pipeline":
        pipeline_id, stages = find_or_create_pipeline()
        print(json.dumps({"pipeline_id": pipeline_id, "stages": stages}, indent=2))

    elif args.command == "push-leads":
        with open(args.file) as f:
            leads = json.loads(f.read())
        result = push_leads(leads)
        print(json.dumps(result, indent=2))

    elif args.command == "save-credentials":
        save_credentials(args.token, args.location_id)
        print(json.dumps({"status": "saved", "message": "Credentials saved successfully."}))

    else:
        parser.print_help()


if __name__ == "__main__":
    main()
