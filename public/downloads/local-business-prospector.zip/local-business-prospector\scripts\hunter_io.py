#!/usr/bin/env python3
"""
hunter_io.py - Hunter.io API wrapper for email enrichment
Finds email addresses from domain names using Hunter.io API

Usage:
    python3 hunter_io.py search --domain "example.com"
    python3 hunter_io.py search --domain "example.com" --save
"""

import urllib.request
import urllib.error
import urllib.parse
import json
import sys
import os
import ssl
import time
import argparse
from urllib.parse import urlparse

# Hunter.io API Configuration
HUNTER_API_BASE = "https://api.hunter.io/v2"

# SSL context
SSL_CTX = ssl.create_default_context()
SSL_CTX.check_hostname = False
SSL_CTX.verify_mode = ssl.CERT_NONE

# Retry settings
MAX_RETRIES = 3
RETRY_DELAY = 2
REQUEST_TIMEOUT = 30


def get_api_key():
    """Get Hunter.io API key from environment or config file."""
    # Check environment variable first
    api_key = os.environ.get("HUNTER_IO_API_KEY", "")
    
    # Check config file
    if not api_key:
        config_path = os.path.expanduser("~/.local-business-prospector/hunter_io_key")
        if os.path.isfile(config_path):
            with open(config_path, 'r') as f:
                api_key = f.read().strip()
    
    return api_key


def save_api_key(api_key):
    """Save Hunter.io API key to config file."""
    config_dir = os.path.expanduser("~/.local-business-prospector")
    os.makedirs(config_dir, exist_ok=True)
    
    with open(os.path.join(config_dir, "hunter_io_key"), 'w') as f:
        f.write(api_key)
    
    return True


def make_request(url, retries=MAX_RETRIES):
    """Make HTTP request with retries."""
    headers = {
        "User-Agent": "LocalBusinessProspector/3.0",
        "Accept": "application/json",
    }
    
    for attempt in range(retries):
        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT, context=SSL_CTX) as resp:
                return json.loads(resp.read().decode('utf-8'))
        except urllib.error.HTTPError as e:
            if e.code == 429 and attempt < retries - 1:
                time.sleep(RETRY_DELAY * (attempt + 1))
                continue
            error_body = e.read().decode('utf-8')
            try:
                error_data = json.loads(error_body)
                raise RuntimeError(f"Hunter.io API error: {error_data.get('errors', [{}])[0].get('details', 'Unknown error')}")
            except json.JSONDecodeError:
                raise RuntimeError(f"Hunter.io API error: {e.code}")
        except Exception as e:
            if attempt < retries - 1:
                time.sleep(RETRY_DELAY * (attempt + 1))
            else:
                raise


def extract_domain(url_or_domain):
    """Extract clean domain from URL or domain string."""
    if not url_or_domain:
        return None
    
    # Add protocol if missing
    if not url_or_domain.startswith(('http://', 'https://')):
        url_or_domain = 'https://' + url_or_domain
    
    try:
        parsed = urlparse(url_or_domain)
        domain = parsed.netloc or parsed.path
        
        # Remove www. prefix
        if domain.startswith('www.'):
            domain = domain[4:]
        
        # Remove port if present
        if ':' in domain:
            domain = domain.split(':')[0]
        
        return domain.lower()
    except Exception:
        return None


def search_domain(domain_or_url, api_key=None):
    """Search for emails on a domain using Hunter.io."""
    if not api_key:
        api_key = get_api_key()
    
    if not api_key:
        raise RuntimeError(
            "Hunter.io API key not found. "
            "Set HUNTER_IO_API_KEY environment variable or run: "
            "python3 hunter_io.py save-key --key YOUR_API_KEY"
        )
    
    domain = extract_domain(domain_or_url)
    if not domain:
        raise ValueError(f"Could not extract valid domain from: {domain_or_url}")
    
    url = f"{HUNTER_API_BASE}/domain-search?domain={urllib.parse.quote(domain)}&api_key={urllib.parse.quote(api_key)}"
    
    response = make_request(url)
    
    return {
        "domain": domain,
        "emails": response.get("data", {}).get("emails", []),
        "pattern": response.get("data", {}).get("pattern", ""),
        "organization": response.get("data", {}).get("organization", ""),
        "total_emails": len(response.get("data", {}).get("emails", [])),
    }


def get_best_email(domain_result):
    """Get the best email from Hunter.io results."""
    emails = domain_result.get("emails", [])
    
    if not emails:
        return None
    
    # Sort by confidence score (highest first)
    sorted_emails = sorted(
        emails,
        key=lambda x: (x.get("confidence", 0), x.get("verification", {}).get("status") == "valid"),
        reverse=True
    )
    
    # Return the best email
    best = sorted_emails[0]
    return {
        "email": best.get("value"),
        "confidence": best.get("confidence", 0),
        "type": best.get("type", "unknown"),
        "position": best.get("position", ""),
        "first_name": best.get("first_name", ""),
        "last_name": best.get("last_name", ""),
    }


def enrich_leads_with_emails(leads, api_key=None):
    """Enrich a list of leads with emails from Hunter.io."""
    if not api_key:
        api_key = get_api_key()
    
    if not api_key:
        print("Warning: Hunter.io API key not configured. Skipping email enrichment.", file=sys.stderr)
        return leads
    
    enriched = []
    
    for lead in leads:
        website = lead.get("website") or lead.get("url", "")
        
        if website:
            try:
                result = search_domain(website, api_key)
                best_email = get_best_email(result)
                
                if best_email:
                    lead["email"] = best_email["email"]
                    lead["email_confidence"] = best_email["confidence"]
                    lead["email_source"] = "hunter.io"
                    print(f"Found email for {lead.get('title', lead.get('name', 'Unknown'))}: {best_email['email']} ({best_email['confidence']}% confidence)", file=sys.stderr)
                else:
                    lead["email"] = None
                    lead["email_confidence"] = 0
                    
            except Exception as e:
                print(f"Could not find email for {lead.get('title', lead.get('name', 'Unknown'))}: {e}", file=sys.stderr)
                lead["email"] = None
                lead["email_confidence"] = 0
        else:
            lead["email"] = None
            lead["email_confidence"] = 0
        
        enriched.append(lead)
        
        # Small delay to avoid rate limits
        time.sleep(0.5)
    
    return enriched


def format_email_result(result):
    """Format Hunter.io result for display."""
    lines = []
    lines.append(f"Domain: {result['domain']}")
    lines.append(f"Organization: {result.get('organization', 'N/A')}")
    lines.append(f"Pattern: {result.get('pattern', 'N/A')}")
    lines.append(f"Total emails found: {result['total_emails']}")
    lines.append("")
    
    if result['emails']:
        lines.append("Top emails:")
        for i, email in enumerate(result['emails'][:5], 1):
            confidence = email.get('confidence', 0)
            email_type = email.get('type', 'unknown')
            position = email.get('position', '')
            name = f"{email.get('first_name', '')} {email.get('last_name', '')}".strip()
            
            lines.append(f"  {i}. {email['value']}")
            lines.append(f"     Confidence: {confidence}% | Type: {email_type}")
            if position:
                lines.append(f"     Position: {position}")
            if name:
                lines.append(f"     Name: {name}")
            lines.append("")
    
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description="Hunter.io Email Enrichment")
    sub = parser.add_subparsers(dest="command")
    
    # search command
    search_cmd = sub.add_parser("search", help="Search for emails on a domain")
    search_cmd.add_argument("--domain", required=True, help="Domain to search (e.g., example.com)")
    search_cmd.add_argument("--key", help="Hunter.io API key (optional if saved)")
    
    # save-key command
    save_cmd = sub.add_parser("save-key", help="Save Hunter.io API key")
    save_cmd.add_argument("--key", required=True, help="Your Hunter.io API key")
    
    # test command
    test_cmd = sub.add_parser("test", help="Test Hunter.io connection")
    
    args = parser.parse_args()
    
    if args.command == "search":
        try:
            result = search_domain(args.domain, args.key)
            print(format_email_result(result))
        except Exception as e:
            print(f"Error: {e}", file=sys.stderr)
            sys.exit(1)
    
    elif args.command == "save-key":
        try:
            save_api_key(args.key)
            print("API key saved successfully!")
        except Exception as e:
            print(f"Error saving API key: {e}", file=sys.stderr)
            sys.exit(1)
    
    elif args.command == "test":
        try:
            api_key = get_api_key()
            if not api_key:
                print("Error: No API key configured. Run: python3 hunter_io.py save-key --key YOUR_KEY", file=sys.stderr)
                sys.exit(1)
            
            # Test with a known domain
            result = search_domain("hunter.io", api_key)
            print(f"Connection successful! Found {result['total_emails']} emails for hunter.io")
        except Exception as e:
            print(f"Connection failed: {e}", file=sys.stderr)
            sys.exit(1)
    
    else:
        parser.print_help()


if __name__ == "__main__":
    main()