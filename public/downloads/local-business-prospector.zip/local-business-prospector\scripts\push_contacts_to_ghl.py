#!/usr/bin/env python3
"""
Push multiple contacts to GHL with smart phone number handling.
First contact per business gets phone number, additional contacts get email only.
"""
import sys
import os
import subprocess
import json

# Path to ghl-workflow skill
GHL_SKILL_PATH = r"C:\Users\Administrator\.openclaw\skills\ghl-workflow"
GHL_SCRIPT = os.path.join(GHL_SKILL_PATH, "scripts", "ghl_workflow.py")


def push_contact(email, first_name, last_name, phone, company, tags, workflow_id=None):
    """Push a single contact to GHL with tags and optional workflow enrollment"""
    data = {
        "firstName": first_name,
        "lastName": last_name,
        "email": email,
        "companyName": company,
        "tags": tags if isinstance(tags, list) else [tags]
    }
    
    # Only add phone if provided (avoid duplicate phone number errors)
    if phone and phone not in ["None", "", "null"]:
        data["phone"] = phone
    
    try:
        # Call ghl_workflow.py to create contact
        result = subprocess.run(
            ["python", GHL_SCRIPT, "add-contact", "--data", json.dumps(data)],
            capture_output=True,
            text=True
        )
        
        if result.returncode != 0:
            return {"error": result.stderr, "email": email}
        
        contact_data = json.loads(result.stdout)
        
        # If workflow_id provided, enroll contact
        if workflow_id and "id" in contact_data:
            workflow_result = subprocess.run(
                ["python", GHL_SCRIPT, "add-to-workflow", 
                 "--id", contact_data["id"], 
                 "--workflow-id", workflow_id],
                capture_output=True,
                text=True
            )
            
            if workflow_result.returncode == 0:
                contact_data["workflow_enrolled"] = True
            else:
                contact_data["workflow_enrolled"] = False
                contact_data["workflow_error"] = workflow_result.stderr
        
        return contact_data
        
    except Exception as e:
        return {"error": str(e), "email": email}


def push_leads_batch(leads_data, tag, workflow_id=None):
    """
    Push multiple leads to GHL with smart phone handling.
    
    Args:
        leads_data: List of dict with keys: business_name, emails (list), phone, company
        tag: Tag to apply to all contacts
        workflow_id: Optional workflow ID to enroll contacts
    
    Returns:
        List of results
    """
    results = []
    
    for business in leads_data:
        business_name = business.get("business_name", "Unknown")
        emails = business.get("emails", [])
        phone = business.get("phone")
        company = business.get("company", business_name)
        
        for idx, email_data in enumerate(emails):
            email = email_data.get("email")
            first_name = email_data.get("first_name", "Contact")
            last_name = email_data.get("last_name", business_name)
            
            # First contact gets phone, rest get email only
            contact_phone = phone if idx == 0 else None
            
            result = push_contact(
                email=email,
                first_name=first_name,
                last_name=last_name,
                phone=contact_phone,
                company=company,
                tags=tag,
                workflow_id=workflow_id
            )
            
            results.append({
                "business": business_name,
                "email": email,
                "phone_assigned": idx == 0,
                "success": "id" in result,
                "contact_id": result.get("id"),
                "workflow_enrolled": result.get("workflow_enrolled", False),
                "error": result.get("error")
            })
    
    return results


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Push leads to GHL")
    parser.add_argument("--file", required=True, help="JSON file with leads data")
    parser.add_argument("--tag", required=True, help="Tag to apply")
    parser.add_argument("--workflow-id", help="Optional workflow ID")
    
    args = parser.parse_args()
    
    with open(args.file) as f:
        leads_data = json.load(f)
    
    results = push_leads_batch(leads_data, args.tag, args.workflow_id)
    
    print(json.dumps(results, indent=2))
