#!/usr/bin/env python3
"""
web_scraper.py — Fallback scraper for Local Business Prospector
Uses only Python standard library (urllib, json, re, html.parser)
No pip installs required.

Usage:
    python3 web_scraper.py search --type "restaurants" --location "Austin TX" --count 10
    python3 web_scraper.py search --type "dentists" --location "Miami FL" --count 5 --source google
    python3 web_scraper.py search --type "gyms" --location "Denver CO" --source yelp
"""

import urllib.request
import urllib.parse
import urllib.error
import json
import re
import sys
import ssl
import time
import html
import argparse
from html.parser import HTMLParser

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/124.0.0.0 Safari/537.36"
)

HEADERS = {
    "User-Agent": USER_AGENT,
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
    "Accept-Encoding": "identity",
}

# Retry / timeout
MAX_RETRIES = 3
REQUEST_TIMEOUT = 15
RETRY_DELAY = 2

# SSL context that doesn't verify (some environments lack certs)
SSL_CTX = ssl.create_default_context()
SSL_CTX.check_hostname = False
SSL_CTX.verify_mode = ssl.CERT_NONE


# ---------------------------------------------------------------------------
# HTTP helpers
# ---------------------------------------------------------------------------

def _fetch(url, retries=MAX_RETRIES):
    """Fetch a URL and return the decoded body text."""
    for attempt in range(retries):
        try:
            req = urllib.request.Request(url, headers=HEADERS)
            with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT, context=SSL_CTX) as resp:
                data = resp.read()
                # Try common encodings
                for enc in ("utf-8", "latin-1", "ascii"):
                    try:
                        return data.decode(enc)
                    except UnicodeDecodeError:
                        continue
                return data.decode("utf-8", errors="replace")
        except (urllib.error.URLError, urllib.error.HTTPError, OSError) as exc:
            if attempt < retries - 1:
                time.sleep(RETRY_DELAY * (attempt + 1))
            else:
                raise RuntimeError(f"Failed to fetch {url}: {exc}") from exc


def _clean(text):
    """Strip HTML tags and collapse whitespace."""
    text = re.sub(r"<[^>]+>", " ", text)
    text = html.unescape(text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


# ---------------------------------------------------------------------------
# Google Maps scraper (via Google search results page)
# ---------------------------------------------------------------------------

def _scrape_google_maps(business_type, location, count):
    """
    Scrape Google search results for local businesses.
    Uses the regular Google search with a maps-oriented query.
    Returns a list of business dicts.
    """
    results = []
    query = f"{business_type} in {location}"
    encoded = urllib.parse.quote_plus(query)
    url = f"https://www.google.com/search?q={encoded}&num={count + 10}&gl=us&hl=en"

    try:
        body = _fetch(url)
    except RuntimeError:
        return results

    # Extract structured data from search results
    # Look for local pack / business listings
    # Pattern: business name, address, phone, rating, reviews
    
    # Try to find local business cards in the HTML
    # Google embeds business data in various div structures
    
    # Method 1: Extract from search result snippets
    # Look for patterns like "Rating: X.X · N reviews"
    blocks = re.split(r'<div class="[^"]*"[^>]*>', body)
    
    current_biz = {}
    seen_names = set()
    
    for block in blocks:
        clean_block = _clean(block)
        if not clean_block or len(clean_block) < 10:
            continue
        
        # Look for rating patterns: "4.5(123)" or "4.5 · 123 reviews"
        rating_match = re.search(
            r'(\d\.\d)\s*[\(·]\s*(\d[\d,]*)\s*(?:reviews?\)?|ratings?\)?|\))',
            clean_block
        )
        
        # Look for phone patterns
        phone_match = re.search(
            r'\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}',
            clean_block
        )
        
        # Look for address patterns (city, state ZIP)
        addr_match = re.search(
            r'\d+\s+[\w\s]+(?:St|Ave|Blvd|Dr|Rd|Ln|Way|Ct|Pl|Pkwy|Hwy|Cir)'
            r'[\w\s,]*\b[A-Z]{2}\b\s*\d{5}',
            clean_block
        )
        
        # If we find a rating, this is likely a business listing
        if rating_match:
            # Try to extract the business name (text before the rating)
            name_text = clean_block[:clean_block.find(rating_match.group(0))].strip()
            # Take last meaningful segment as name
            name_parts = [p.strip() for p in re.split(r'[|·]', name_text) if p.strip()]
            name = name_parts[-1] if name_parts else name_text
            name = name[:100].strip(" ·-–—")
            
            if name and len(name) > 2 and name not in seen_names:
                seen_names.add(name)
                biz = {
                    "name": name,
                    "rating": float(rating_match.group(1)),
                    "reviews_count": int(rating_match.group(2).replace(",", "")),
                    "phone": phone_match.group(0) if phone_match else None,
                    "address": addr_match.group(0).strip() if addr_match else None,
                    "website": None,
                    "source": "google_search",
                    "category": business_type,
                    "location_query": location,
                }
                results.append(biz)
    
    # Method 2: Try to extract from JSON-LD or embedded data
    json_ld_matches = re.findall(
        r'<script[^>]*type="application/ld\+json"[^>]*>(.*?)</script>',
        body, re.DOTALL
    )
    for jld in json_ld_matches:
        try:
            data = json.loads(jld)
            items = data if isinstance(data, list) else [data]
            for item in items:
                if item.get("@type") in ("LocalBusiness", "Restaurant", "Store",
                                          "MedicalBusiness", "HealthAndBeautyBusiness"):
                    name = item.get("name", "")
                    if name and name not in seen_names:
                        seen_names.add(name)
                        addr_obj = item.get("address", {})
                        address = ", ".join(filter(None, [
                            addr_obj.get("streetAddress"),
                            addr_obj.get("addressLocality"),
                            addr_obj.get("addressRegion"),
                            addr_obj.get("postalCode"),
                        ]))
                        rating_obj = item.get("aggregateRating", {})
                        biz = {
                            "name": name,
                            "rating": float(rating_obj.get("ratingValue", 0)),
                            "reviews_count": int(rating_obj.get("reviewCount", 0)),
                            "phone": item.get("telephone"),
                            "address": address or None,
                            "website": item.get("url"),
                            "source": "google_structured",
                            "category": business_type,
                            "location_query": location,
                        }
                        results.append(biz)
        except (json.JSONDecodeError, ValueError, TypeError):
            continue

    # Extract any URLs that look like business websites
    urls = re.findall(r'href="(https?://(?!google|gstatic|youtube|maps\.google)[^"]+)"', body)
    for url_found in urls[:count * 2]:
        # Try to match URLs to businesses
        for biz in results:
            if biz["website"] is None:
                domain = re.search(r'https?://([^/]+)', url_found)
                if domain:
                    d = domain.group(1).lower()
                    # Skip common non-business domains
                    if not any(skip in d for skip in [
                        "google", "yelp", "facebook", "twitter", "instagram",
                        "youtube", "wikipedia", "bing", "yahoo", "tripadvisor",
                        "bbb.org", "yellowpages", "mapquest"
                    ]):
                        biz_name_lower = biz["name"].lower().replace(" ", "")
                        if any(word in d for word in biz_name_lower.split()[:2] if len(word) > 3):
                            biz["website"] = url_found
                            break

    return results[:count]


# ---------------------------------------------------------------------------
# Yelp scraper
# ---------------------------------------------------------------------------

def _scrape_yelp(business_type, location, count):
    """
    Scrape Yelp search results for local businesses.
    Returns a list of business dicts.
    """
    results = []
    query = urllib.parse.quote_plus(business_type)
    loc = urllib.parse.quote_plus(location)
    url = f"https://www.yelp.com/search?find_desc={query}&find_loc={loc}"

    try:
        body = _fetch(url)
    except RuntimeError:
        return results

    seen_names = set()

    # Yelp embeds business data in JSON within script tags
    # Look for the main search results data
    json_matches = re.findall(
        r'<!--({.*?})-->',
        body, re.DOTALL
    )
    
    # Also try to find JSON in script tags
    script_matches = re.findall(
        r'<script[^>]*>(.*?)</script>',
        body, re.DOTALL
    )
    
    for script_content in script_matches:
        # Look for business data patterns in Yelp's JavaScript
        biz_matches = re.findall(
            r'"name"\s*:\s*"([^"]+)".*?"rating"\s*:\s*(\d+\.?\d*).*?"reviewCount"\s*:\s*(\d+)',
            script_content, re.DOTALL
        )
        for name, rating, reviews in biz_matches:
            if name not in seen_names and len(name) > 2:
                seen_names.add(name)
                # Try to find phone near this business
                phone_match = re.search(
                    rf'{re.escape(name)}.*?"phone"\s*:\s*"([^"]+)"',
                    script_content, re.DOTALL
                )
                addr_match = re.search(
                    rf'{re.escape(name)}.*?"address"\s*:\s*\{{([^}}]+)\}}',
                    script_content, re.DOTALL
                )
                url_match = re.search(
                    rf'{re.escape(name)}.*?"website"\s*:\s*"([^"]+)"',
                    script_content, re.DOTALL
                )
                
                address = None
                if addr_match:
                    addr_text = addr_match.group(1)
                    parts = re.findall(r'"(?:street|city|state|zip)"\s*:\s*"([^"]+)"', addr_text)
                    address = ", ".join(parts) if parts else None
                
                biz = {
                    "name": name,
                    "rating": float(rating),
                    "reviews_count": int(reviews),
                    "phone": phone_match.group(1) if phone_match else None,
                    "address": address,
                    "website": url_match.group(1) if url_match else None,
                    "source": "yelp",
                    "category": business_type,
                    "location_query": location,
                }
                results.append(biz)
                if len(results) >= count:
                    break
        if len(results) >= count:
            break

    # Fallback: parse HTML directly for business cards
    if len(results) < count:
        # Yelp uses specific patterns for business listings
        # Look for business name + rating + review count patterns
        listing_pattern = re.findall(
            r'<a[^>]*href="/biz/([^"?]+)"[^>]*>([^<]+)</a>',
            body
        )
        
        for biz_slug, biz_name in listing_pattern:
            biz_name = _clean(biz_name).strip()
            if (biz_name and len(biz_name) > 2 and biz_name not in seen_names
                    and not biz_name.startswith("Read") and not biz_name.startswith("Write")):
                seen_names.add(biz_name)
                
                # Try to find rating near this listing
                slug_context = body[body.find(biz_slug):body.find(biz_slug) + 2000]
                rating_match = re.search(r'(\d\.\d)\s*(?:star|rating)', slug_context, re.I)
                review_match = re.search(r'(\d+)\s*review', slug_context, re.I)
                phone_match = re.search(r'\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}', slug_context)
                
                biz = {
                    "name": biz_name,
                    "rating": float(rating_match.group(1)) if rating_match else 0.0,
                    "reviews_count": int(review_match.group(1)) if review_match else 0,
                    "phone": phone_match.group(0) if phone_match else None,
                    "address": None,
                    "website": None,
                    "source": "yelp",
                    "category": business_type,
                    "location_query": location,
                }
                results.append(biz)
                if len(results) >= count:
                    break

    return results[:count]


# ---------------------------------------------------------------------------
# Web directory / Yellow Pages scraper
# ---------------------------------------------------------------------------

def _scrape_directories(business_type, location, count):
    """
    Scrape YellowPages.com for local businesses.
    Returns a list of business dicts.
    """
    results = []
    query = urllib.parse.quote_plus(business_type)
    loc = urllib.parse.quote_plus(location)
    url = f"https://www.yellowpages.com/search?search_terms={query}&geo_location_terms={loc}"

    try:
        body = _fetch(url)
    except RuntimeError:
        return results

    seen_names = set()

    # YellowPages has relatively clean HTML structure
    # Business listings are in divs with class "result"
    # Each has: business-name, street-address, locality, phone, links
    
    # Extract business name blocks
    name_matches = re.findall(
        r'class="business-name"[^>]*>(?:<[^>]+>)*([^<]+)',
        body
    )
    
    phone_matches = re.findall(
        r'class="phones[^"]*"[^>]*>([^<]+)',
        body
    )
    
    addr_matches = re.findall(
        r'class="street-address"[^>]*>([^<]+)',
        body
    )
    
    locality_matches = re.findall(
        r'class="locality"[^>]*>([^<]+)',
        body
    )
    
    website_matches = re.findall(
        r'class="track-visit-website"[^>]*href="([^"]+)"',
        body
    )
    
    for i, name in enumerate(name_matches[:count]):
        name = _clean(name).strip()
        if name and name not in seen_names:
            seen_names.add(name)
            
            phone = _clean(phone_matches[i]).strip() if i < len(phone_matches) else None
            street = _clean(addr_matches[i]).strip() if i < len(addr_matches) else ""
            city = _clean(locality_matches[i]).strip() if i < len(locality_matches) else ""
            address = f"{street}, {city}".strip(", ") if street or city else None
            website = website_matches[i] if i < len(website_matches) else None
            
            biz = {
                "name": name,
                "rating": 0.0,
                "reviews_count": 0,
                "phone": phone,
                "address": address,
                "website": website,
                "source": "yellowpages",
                "category": business_type,
                "location_query": location,
            }
            results.append(biz)

    return results[:count]


# ---------------------------------------------------------------------------
# Scoring logic (mirrors Apify version exactly)
# ---------------------------------------------------------------------------

def score_lead(biz):
    """
    Score a business lead. Returns (score_label, score_emoji, reason).
    
    Scoring priority (from SKILL.md v2.0.0):
      1. Review count (strongest signal)
      2. Website presence
      3. Social media presence (not available in scraping fallback)
      4. Star rating
    """
    reviews = biz.get("reviews_count", 0) or 0
    rating = biz.get("rating", 0.0) or 0.0
    has_website = bool(biz.get("website"))
    reasons = []

    # --- Determine tier ---
    hot_signals = 0
    warm_signals = 0
    low_signals = 0

    # Review count (strongest signal)
    if reviews < 50:
        hot_signals += 2
        reasons.append(f"Only {reviews} reviews")
    elif reviews <= 150:
        warm_signals += 1
        reasons.append(f"{reviews} reviews (moderate)")
    else:
        low_signals += 2
        reasons.append(f"{reviews} reviews (well-established)")

    # Website presence
    if not has_website:
        hot_signals += 1
        reasons.append("no website")
    else:
        warm_signals += 0.5

    # Star rating
    if rating == 0.0:
        hot_signals += 0.5
        reasons.append("no rating data")
    elif rating < 4.0:
        hot_signals += 1
        reasons.append(f"{rating} stars (below average)")
    elif rating <= 4.5:
        warm_signals += 0.5
    else:
        low_signals += 1
        reasons.append(f"{rating} stars (strong)")

    # Determine final score
    if hot_signals >= 2:
        label = "Hot"
        emoji = "\U0001f525"
        reason_prefix = "Great prospect"
    elif warm_signals >= 1 and hot_signals >= 1:
        label = "Warm"
        emoji = "\U0001f7e1"
        reason_prefix = "Decent prospect"
    elif low_signals >= 2:
        label = "Low"
        emoji = "\u26aa"
        reason_prefix = "Low priority"
    else:
        label = "Warm"
        emoji = "\U0001f7e1"
        reason_prefix = "Moderate prospect"

    reason = f"{reason_prefix} — {', '.join(reasons)}."
    return label, emoji, reason


# ---------------------------------------------------------------------------
# Merge and deduplicate
# ---------------------------------------------------------------------------

def _deduplicate(results):
    """Remove duplicate businesses by normalized name."""
    seen = set()
    unique = []
    for biz in results:
        key = re.sub(r"[^a-z0-9]", "", biz["name"].lower())
        if key not in seen and len(key) > 2:
            seen.add(key)
            unique.append(biz)
    return unique


# ---------------------------------------------------------------------------
# Main search orchestrator
# ---------------------------------------------------------------------------

def search_businesses(business_type, location, count=10, source="all"):
    """
    Search for local businesses using web scraping.
    
    Args:
        business_type: e.g. "restaurants", "dentists", "gyms"
        location: e.g. "Austin TX", "Miami FL"
        count: number of results desired
        source: "google", "yelp", "directories", or "all"
    
    Returns:
        List of scored business dicts, sorted best-to-worst.
    """
    all_results = []

    if source in ("google", "all"):
        try:
            google_results = _scrape_google_maps(business_type, location, count + 5)
            all_results.extend(google_results)
        except Exception:
            pass  # Silently continue to next source

    if source in ("yelp", "all"):
        try:
            yelp_results = _scrape_yelp(business_type, location, count + 5)
            all_results.extend(yelp_results)
        except Exception:
            pass

    if source in ("directories", "all"):
        try:
            dir_results = _scrape_directories(business_type, location, count + 5)
            all_results.extend(dir_results)
        except Exception:
            pass

    # Deduplicate
    all_results = _deduplicate(all_results)

    # Score each lead
    for biz in all_results:
        label, emoji, reason = score_lead(biz)
        biz["score_label"] = label
        biz["score_emoji"] = emoji
        biz["score_reason"] = reason

    # Sort: Hot first, then Warm, then Low
    priority = {"Hot": 0, "Warm": 1, "Low": 2}
    all_results.sort(key=lambda b: (priority.get(b["score_label"], 9), b.get("reviews_count", 999)))

    return all_results[:count]


def format_results(results):
    """Format results for display, matching the SKILL.md output format."""
    if not results:
        return "No businesses found. Try broadening the location or simplifying the business type."

    lines = []
    for i, biz in enumerate(results, 1):
        lines.append(f"{i}. {biz['name']}")
        lines.append(f"   Score: {biz['score_emoji']} {biz['score_label']}")
        lines.append(f"   Type: {biz.get('category', 'N/A')}")
        lines.append(f"   Location: {biz.get('address') or biz.get('location_query', 'Not listed')}")
        lines.append(f"   Phone: {biz.get('phone') or 'Not listed'}")
        lines.append(f"   Website: {biz.get('website') or 'None'}")
        rating_str = f"{biz.get('rating', 0)}⭐" if biz.get("rating") else "N/A"
        lines.append(f"   Reviews: {biz.get('reviews_count', 0)} ({rating_str})")
        lines.append(f"   Source: {biz.get('source', 'web')}")
        lines.append(f"   Why: {biz.get('score_reason', '')}")
        if biz.get("email"):
            lines.append(f"   Email: {biz['email']}")
        lines.append("")

    return "\n".join(lines)


def results_to_json(results):
    """Return results as a JSON string for programmatic use."""
    return json.dumps(results, indent=2, ensure_ascii=False)


# ---------------------------------------------------------------------------
# CLI interface
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="Local Business Prospector — Web Scraping Fallback"
    )
    sub = parser.add_subparsers(dest="command")

    # search command
    sp = sub.add_parser("search", help="Search for local businesses")
    sp.add_argument("--type", required=True, help="Business type (e.g. restaurants, dentists)")
    sp.add_argument("--location", required=True, help="City/area (e.g. Austin TX)")
    sp.add_argument("--count", type=int, default=10, help="Number of results (default: 10)")
    sp.add_argument("--source", default="all",
                    choices=["google", "yelp", "directories", "all"],
                    help="Data source (default: all)")
    sp.add_argument("--format", default="text", choices=["text", "json"],
                    help="Output format (default: text)")

    args = parser.parse_args()

    if args.command == "search":
        results = search_businesses(
            business_type=args.type,
            location=args.location,
            count=args.count,
            source=args.source,
        )
        if args.format == "json":
            print(results_to_json(results))
        else:
            print(format_results(results))
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
